# -*- coding: utf-8 -*-

import zipfile, xbmcaddon, xbmc, uservar, sys,logging
from resources.libs import wizard as wiz

ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
LOGFILES       = ['xbmc.log', 'xbmc.old.log', 'kodi.log', 'kodi.old.log', 'spmc.log', 'spmc.old.log', 'tvmc.log', 'tvmc.old.log', 'Thumbs.db', '.gitignore', '.DS_Store']
bad_files      = ['onechannelcache.db', 'saltscache.db', 'saltscache.db-shm', 'saltscache.db-wal', 'saltshd.lite.db', 'saltshd.lite.db-shm', 'saltshd.lite.db-wal', 'queue.db', 'commoncache.db', 'access.log', 'trakt.db', 'video_cache.db']

def all(_in, _out, dp=None, ignore=None, title=None,keep_userdata=False):
	if dp: return allWithProgress(_in, _out, dp, ignore, title,keep_userdata)
	else: return allNoProgress(_in, _out, ignore)
def all2(_in, _out, dp2=None, ignore=None, title=None,keep_userdata=False):
	if dp2: return allWithProgress2(_in, _out, dp2, ignore, title,keep_userdata)


def allNoProgress(_in, _out, ignore):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception as e:
		print (e)
		return False
	return True

def allWithProgress(_in, _out, dp, ignore, title,keep_userdata):
    count = 0; errors = 0; error = ''; update = 0; size = 0; excludes = []
    try:
        zin = zipfile.ZipFile(_in,  'r')
    except Exception as e:
        errors += 1; error += '%s\n' % e
        wiz.log('Error Checking Zip: %s' % str(e), 5)
        return update, errors, error
    
    nFiles = float(len(zin.namelist()))
    zipsize = wiz.convertSize(sum([item.file_size for item in zin.infolist()]))

    zipit = str(_in).replace('\\', '/').split('/')
    title = title if not title == None else zipit[-1].replace('.zip', '')
    dragon=wiz.getS("dragon")
    for item in zin.infolist():
        try:
            str(item.filename).encode('ascii')
        except UnicodeEncodeError:
            continue
        except UnicodeDecodeError:
            continue
        count += 1; prog = int(count / nFiles * 100); size += item.file_size
        file = (item.filename).split('/')
        skip = False
        line1  = 'מחלץ קבצים'
        line2  = '[COLOR %s][B]File:[/B][/COLOR] [COLOR %s]%s/%s[/COLOR] ' % (COLOR2, COLOR1, count, int(nFiles))
        line2 += '[COLOR %s][B]Size:[/B][/COLOR] [COLOR %s]%s/%s[/COLOR]' % (COLOR2, COLOR1, wiz.convertSize(size), zipsize)
        line3  = '[COLOR %s]%s[/COLOR]' % (COLOR1, item.filename)
        
        if 'plugin.video.dreamspeed' in item.filename and dragon=='false': skip = True
        # elif 'db.sqlite' in item.filename:  skip = True
        # elif 'db.sqlite-shm' in item.filename:  skip = True
        # elif 'db.sqlite-wal' in item.filename:  skip = True
        # elif 'td.binlog' in item.filename:  skip = True
        elif file[0] == 'addons' and file[1] in excludes: skip = True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] in excludes: skip = True
        elif file[-1] in LOGFILES: skip = True
        elif file[-1] in bad_files: skip = True
        elif file[-1].endswith('.csv'): skip = True
        elif not (item.filename).find(ADDON_ID)                          == -1 and ignore == None: skip = True
        if skip == True: wiz.log("Skipping: %s" % item.filename, 5)
        else:
            try:
                zin.extract(item, _out)
            except Exception as e:
                pass
        dp.update(prog, line1+'\n'+ line2+'\n'+ line3)
        if dp.iscanceled(): break
    if dp.iscanceled(): 
        dp.close()
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Extract Cancelled[/COLOR]" % COLOR2,1500)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
    return prog, errors, error
def allWithProgress2(_in, _out, dp2, ignore, title,keep_userdata):

    count = 0; errors = 0; error = ''; update = 0; size = 0; excludes = []
    try:
        zin = zipfile.ZipFile(_in,  'r')
    except Exception as e:
        errors += 1; error += '%s\n' % e
        wiz.log('Error Checking Zip: %s' % str(e), 5)
        return update, errors, error

    nFiles = float(len(zin.namelist()))
    zipsize = wiz.convertSize(sum([item.file_size for item in zin.infolist()]))
    zipit = str(_in).replace('\\', '/').split('/')
    title = title if not title == None else zipit[-1].replace('.zip', '')
    dragon=wiz.getS("dragon")
    for item in zin.infolist():
        try:
            str(item.filename).encode('ascii')
        except UnicodeEncodeError:
            continue
        except UnicodeDecodeError:
            continue
        count += 1; prog = int(count / nFiles * 100); size += item.file_size
        file = (item.filename).split('/')
        skip = False
        line2  = 'המתן'#'File:%s/%s' % (count, int(nFiles))
        line3  = 'מחלץ'#'%s' % (item.filename.encode('ascii', errors='ignore').decode('ascii', errors='ignore'))
        if 'plugin.video.dreamspeed' in item.filename and dragon=='false': skip = True
        elif file[0] == 'addons' and file[1] in excludes: skip = True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] in excludes: skip = True
        elif file[-1] in LOGFILES: skip = True
        elif file[-1] in bad_files: skip = True
        elif file[-1].endswith('.csv'): skip = True
        elif not (item.filename).find(ADDON_ID)                          == -1 and ignore == None: skip = True
        if skip == True: wiz.log("Skipping: %s" % item.filename, 5)
        else:
            try:
                zin.extract(item, _out)
            except Exception as e:
                pass
        dp2.update(prog, line3, line2)
    return prog, errors, error
