# coding: utf-8
import xbmcaddon,base64

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'Anonymous TV' 
EXCLUDES       = [ADDON_ID, 'repository.utv']
UPDATECHECK    = 0
APKFILE        = ''
PATH           = xbmcaddon.Addon().getAddonInfo('path')

# --- עודכן לריפו החדש שלך (RAW) ---
F='aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0pFR3BleGQva2xzb2Rqd3B3c25jbi9tYWluL3dpemFyZHVwZGF0ZS54bWw='
N='aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0pFR3BleGQva2xzb2Rqd3B3c25jbi9tYWluL2Zhc3R1cGRhdGUudHh0'
# -------------------------------

ICONBUILDS     = 'http://'
SPACER         = '[COLOR red]----------------------------------[/COLOR]'
COLOR1         = 'gold'
COLOR2         = 'white'
COLOR3         = 'red'
COLOR3         = 'blue'
THEME1         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
THEME4         = '[COLOR '+COLOR1+']%s[/COLOR] [COLOR '+COLOR2+'] :מספר גירסה[/COLOR]'
F=F.replace('!','').replace('$','')
CONTACTICON    = 'http://'
CONTACTFANART  = 'http://'
N=N.replace('!','').replace('$','')
#########################################################
WIZARDFILE     = base64.b64decode(F).decode('utf-8')
NOTIFICATION   = base64.b64decode(N).decode('utf-8')
HEADERTYPE     = 'Image'
HEADERMESSAGE  = ''
#########################################################
