#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
import re
import os

# הגדרות בסיסיות
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_url = sys.argv[0]

# נתיבים ללוגואים
ADDON_PATH = addon.getAddonInfo('path')
ICON_PATH = os.path.join(ADDON_PATH, 'icon.png')
STATE_ICON_PATH = os.path.join(ADDON_PATH, 'state.png')

# URL לקובץ M3U מקורי
M3U_URL = "https://raw.githubusercontent.com/nightah/daddylive/refs/heads/main/daddylive-channels-tivimate.m3u8"

# Headers נדרשים
HEADERS = {
    'Origin': 'https://jxoplay.xyz',
    'Referer': 'https://jxoplay.xyz/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36'
}

def download_and_parse_m3u():
    """הורדה וניתוח ישיר של קובץ M3U מהאינטרנט"""
    try:
        response = requests.get(M3U_URL, timeout=30)
        response.raise_for_status()
        content = response.text
        
        channels = []
        lines = content.split('\n')
        current_channel = {}
        
        for line in lines:
            line = line.strip()
            
            if line.startswith('#EXTINF:'):
                current_channel = {}
                
                # חילוץ group-title
                group_match = re.search(r'group-title="([^"]*)"', line)
                current_channel['group'] = group_match.group(1) if group_match else 'אחר'
                
                # חילוץ tvg-logo
                logo_match = re.search(r'tvg-logo="([^"]*)"', line)
                current_channel['logo'] = logo_match.group(1) if logo_match else ''
                
                # חילוץ שם הערוץ - רק החלק שאחרי הפסיק האחרון
                if ',' in line:
                    name_part = line.split(',')[-1].strip()
                    current_channel['name'] = name_part
                    
            elif line and not line.startswith('#') and current_channel:
                # זה URL של ערוץ
                if '|' in line:
                    # אם יש Headers ב-URL, לוקחים רק את החלק של ה-URL
                    url_part = line.split('|')[0]
                else:
                    url_part = line
                
                # יצירת URL עם Headers לניגון
                url_with_headers = f"{url_part}|Origin={HEADERS['Origin']}&Referer={HEADERS['Referer']}&User-Agent={HEADERS['User-Agent']}"
                current_channel['url'] = url_with_headers
                
                # הוספת הערוץ לרשימה אם יש שם תקין
                if 'name' in current_channel and current_channel['name']:
                    channels.append(current_channel)
                    xbmc.log(f"DaddyVip: Parsed channel: {current_channel['name']} from group: {current_channel.get('group', 'אחר')}", xbmc.LOGDEBUG)
                
                current_channel = {}
        
        xbmc.log(f"DaddyVip: Successfully parsed {len(channels)} channels from online M3U", xbmc.LOGINFO)
        return channels
        
    except Exception as e:
        xbmc.log(f"DaddyVip: Error downloading/parsing M3U: {str(e)}", xbmc.LOGERROR)
        return []

def build_url(query):
    """בניית URL עבור הפלאגין"""
    return addon_url + '?' + urllib.parse.urlencode(query)

def search_channels():
    """חיפוש ערוצים"""
    keyboard = xbmc.Keyboard('', 'הזן מילת חיפוש (לדוגמה: SPORT 1)')
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        search_term = keyboard.getText().lower().strip()
        if search_term:
            xbmcplugin.setContent(addon_handle, 'videos')
            
            # טעינת ערוצים
            channels = download_and_parse_m3u()
            if not channels:
                return
            
            found_channels = []
            for channel in channels:
                # חיפוש בשם הערוץ ובקטגוריה
                channel_name = channel['name'].lower()
                channel_group = channel.get('group', '').lower()
                
                if (search_term in channel_name or 
                    search_term in channel_group or
                    # חיפוש גם ללא רווחים
                    search_term.replace(' ', '') in channel_name.replace(' ', '')):
                    found_channels.append(channel)
            
            if found_channels:
                # מיון התוצאות - ראשון מי שמתחיל עם החיפוש
                found_channels.sort(key=lambda x: (
                    not x['name'].lower().startswith(search_term),
                    x['name'].lower()
                ))
                
                # הצגת מספר התוצאות
                list_item = xbmcgui.ListItem(label=f"נמצאו {len(found_channels)} תוצאות עבור '{search_term}'")
                xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
                
                for channel in found_channels:
                    list_item = xbmcgui.ListItem(label=f"{channel['name']} ({channel.get('group', 'אחר')})")
                    list_item.setInfo('video', {'title': channel['name'], 'genre': channel.get('group', '')})
                    list_item.setProperty('IsPlayable', 'true')
                    
                    # הוספת לוגו - לוגו של הערוץ או icon.png
                    if channel.get('logo'):
                        list_item.setArt({'thumb': channel['logo'], 'icon': channel['logo']})
                    else:
                        list_item.setArt({'thumb': ICON_PATH, 'icon': ICON_PATH})
                    
                    url = build_url({'action': 'play_direct', 'url': channel['url'], 'name': channel['name']})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
                
            else:
                list_item = xbmcgui.ListItem(label=f"לא נמצאו תוצאות עבור '{search_term}'")
                xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
                
                # הצעות חיפוש
                list_item = xbmcgui.ListItem(label="טיפים לחיפוש:")
                xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
                list_item = xbmcgui.ListItem(label="   • נסה חיפוש חלקי (למשל: 'sport' במקום 'sport 1')")
                xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
                list_item = xbmcgui.ListItem(label="   • נסה באנגלית או בעברית")
                xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
            xbmcplugin.endOfDirectory(addon_handle)

def get_countries_list():
    """קבלת רשימת מדינות מהערוצים"""
    channels = download_and_parse_m3u()
    if not channels:
        return []
    
    countries = {}
    
    for channel in channels:
        group = channel.get('group', 'אחר')
        if group not in countries:
            countries[group] = 0
        countries[group] += 1
    
    # מיון לפי כמות ערוצים (יורד) ואז לפי שם
    sorted_countries = sorted(countries.items(), key=lambda x: (-x[1], x[0]))
    return sorted_countries

def show_countries_menu():
    """הצגת תפריט מדינות/קטגוריות"""
    xbmcplugin.setContent(addon_handle, 'files')
    
    countries = get_countries_list()
    if not countries:
        xbmcgui.Dialog().notification('DaddyVip', 'שגיאה בטעינת רשימת המדינות', xbmcgui.NOTIFICATION_ERROR)
        return
    
    for country, count in countries:
        label = f"{country} ({count} ערוצים)"
        list_item = xbmcgui.ListItem(label=label)
        # הוספת אייקון state.png למדינות
        list_item.setArt({'icon': STATE_ICON_PATH, 'thumb': STATE_ICON_PATH})
        
        url = build_url({'action': 'show_country', 'country': country})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(addon_handle)

def show_country_channels(country):
    """הצגת ערוצים של מדינה/קטגוריה ספציפית"""
    xbmcplugin.setContent(addon_handle, 'videos')
    
    channels = download_and_parse_m3u()
    if not channels:
        return
    
    # סינון ערוצים לפי מדינה/קטגוריה
    country_channels = [ch for ch in channels if ch.get('group', 'אחר') == country]
    
    if country_channels:
        # מיון ערוצים לפי שם
        country_channels.sort(key=lambda x: x['name'])
        
        # הצגת כותרת
        list_item = xbmcgui.ListItem(label=f"=== {country} ({len(country_channels)} ערוצים) ===")
        list_item.setInfo('video', {'title': f"{country} ערוצים"})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
        
        # הצגת הערוצים
        for channel in country_channels:
            list_item = xbmcgui.ListItem(label=channel['name'])
            list_item.setInfo('video', {'title': channel['name'], 'genre': country})
            list_item.setProperty('IsPlayable', 'true')
            
            # הוספת לוגו - לוגו של הערוץ או icon.png
            if channel.get('logo'):
                list_item.setArt({'thumb': channel['logo'], 'icon': channel['logo']})
            else:
                list_item.setArt({'thumb': ICON_PATH, 'icon': ICON_PATH})
            
            url = build_url({'action': 'play_direct', 'url': channel['url'], 'name': channel['name']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    else:
        list_item = xbmcgui.ListItem(label=f"לא נמצאו ערוצים עבור {country}")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(addon_handle)

def show_sport_channels():
    """הצגת ערוצי ספורט בלבד"""
    xbmcplugin.setContent(addon_handle, 'videos')
    
    channels = download_and_parse_m3u()
    if not channels:
        return
    
    # סינון ערוצי ספורט
    sport_keywords = ['sport', 'sports', 'football', 'soccer', 'basketball', 'tennis', 'golf', 'baseball', 'hockey', 'espn', 'fox sports', 'sky sports']
    sport_channels = []
    
    for channel in channels:
        channel_name = channel['name'].lower()
        channel_group = channel.get('group', '').lower()
        
        # חיפוש מילות מפתח של ספורט
        is_sport = any(keyword in channel_name or keyword in channel_group for keyword in sport_keywords)
        
        if is_sport:
            sport_channels.append(channel)
    
    if sport_channels:
        # מיון לפי שם
        sport_channels.sort(key=lambda x: x['name'])
        
        # כותרת
        list_item = xbmcgui.ListItem(label=f"=== ערוצי ספורט ({len(sport_channels)} ערוצים) ===")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
        
        for channel in sport_channels:
            list_item = xbmcgui.ListItem(label=channel['name'])
            list_item.setInfo('video', {'title': channel['name'], 'genre': 'ספורט'})
            list_item.setProperty('IsPlayable', 'true')
            
            # הוספת לוגו - לוגו של הערוץ או icon.png
            if channel.get('logo'):
                list_item.setArt({'thumb': channel['logo'], 'icon': channel['logo']})
            else:
                list_item.setArt({'thumb': ICON_PATH, 'icon': ICON_PATH})
            
            url = build_url({'action': 'play_direct', 'url': channel['url'], 'name': channel['name']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    else:
        list_item = xbmcgui.ListItem(label="לא נמצאו ערוצי ספורט")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(addon_handle)

def list_channels():
    """הצגת רשימת ערוצים"""
    xbmcplugin.setContent(addon_handle, 'videos')
    
    channels = download_and_parse_m3u()
    if not channels:
        xbmcgui.Dialog().notification('DaddyVip', 'לא ניתן לטעון ערוצים', xbmcgui.NOTIFICATION_ERROR)
        return
    
    # קיבוץ לפי קטגוריות
    groups = {}
    for channel in channels:
        group = channel.get('group', 'אחר')
        if group not in groups:
            groups[group] = []
        groups[group].append(channel)
    
    # הצגת הערוצים
    for group_name in sorted(groups.keys()):
        # כותרת קבוצה
        list_item = xbmcgui.ListItem(label=f"=== {group_name} ===")
        list_item.setInfo('video', {'title': f"=== {group_name} ==="})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
        
        # ערוצים בקבוצה
        for channel in sorted(groups[group_name], key=lambda x: x['name']):
            list_item = xbmcgui.ListItem(label=channel['name'])
            list_item.setInfo('video', {'title': channel['name'], 'genre': channel.get('group', '')})
            list_item.setProperty('IsPlayable', 'true')
            
            # הוספת לוגו - לוגו של הערוץ או icon.png
            if channel.get('logo'):
                list_item.setArt({'thumb': channel['logo'], 'icon': channel['logo']})
            else:
                list_item.setArt({'thumb': ICON_PATH, 'icon': ICON_PATH})
            
            url = build_url({'action': 'play_direct', 'url': channel['url'], 'name': channel['name']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(addon_handle)

def show_israel_channels():
    """הצגת ערוצים ישראליים בלבד"""
    xbmcplugin.setContent(addon_handle, 'videos')
    
    channels = download_and_parse_m3u()
    if not channels:
        return
    
    israel_channels = [ch for ch in channels if 'israel' in ch['name'].lower()]
    
    if israel_channels:
        # כותרת
        # list_item = xbmcgui.ListItem(label=f"=== ערוצים ישראליים ({len(israel_channels)} ערוצים) ===")
        # xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
        
        for channel in sorted(israel_channels, key=lambda x: x['name']):
            list_item = xbmcgui.ListItem(label=channel['name'])
            list_item.setInfo('video', {'title': channel['name']})
            list_item.setProperty('IsPlayable', 'true')
            
            # הוספת לוגו - לוגו של הערוץ או icon.png
            if channel.get('logo'):
                list_item.setArt({'thumb': channel['logo'], 'icon': channel['logo']})
            else:
                list_item.setArt({'thumb': ICON_PATH, 'icon': ICON_PATH})
            
            url = build_url({'action': 'play_direct', 'url': channel['url'], 'name': channel['name']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    else:
        list_item = xbmcgui.ListItem(label="לא נמצאו ערוצים ישראליים")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="", listitem=list_item, isFolder=False)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(addon_handle)

def play_direct(url, name):
    try:
        xbmc.log(f"DaddyVip: Playing directly: {name} - {url}", xbmc.LOGINFO)

        # כל ה-headers במקום אחד (אפשר להוסיף Accept לשקט תעשייתי)
        hdr = (
            "Accept=*/*&"
            "Origin=https://jxoplay.xyz&"
            "Referer=https://jxoplay.xyz/&"
            "User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"
        )

        li = xbmcgui.ListItem(label=name, path=url)
        li.setProperty('IsPlayable', 'true')

        # חשוב: להפעיל inputstream.adaptive ולהעביר headers גם למניפסט וגם לסגמנטים
        li.setProperty('inputstream', 'inputstream.adaptive')
        # לא חובה אבל לא מזיק: רמז שזה HLS
        # li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # headers לכל הבקשות:
        li.setProperty('inputstream.adaptive.manifest_headers', hdr)
        li.setProperty('inputstream.adaptive.stream_headers',   hdr)

        # (רשות) טיפ קטן: MIME type ל-HLS
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)

        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setMediaType('video')
        info.setMpaa('heb')
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)

    except Exception as e:
        xbmc.log(f"DaddyVip: Error in direct play: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('DaddyVip', f'שגיאה בניגון: {name}', xbmcgui.NOTIFICATION_ERROR)


def main_menu():
    """תפריט ראשי משופר"""
    xbmcplugin.setContent(addon_handle, 'files')
    
    # חיפוש ערוצים (במקום הראשון)
    list_item = xbmcgui.ListItem(label="חיפוש ערוצים")
    list_item.setArt({'icon': ICON_PATH, 'thumb': ICON_PATH})
    url = build_url({'action': 'search'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    
    # רשימת מדינות/קטגוריות
    list_item = xbmcgui.ListItem(label="עיון לפי מדינה/קטגוריה")
    list_item.setArt({'icon': ICON_PATH, 'thumb': ICON_PATH})
    url = build_url({'action': 'countries_menu'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    
    # כל הערוצים
    list_item = xbmcgui.ListItem(label="כל הערוצים")
    list_item.setArt({'icon': ICON_PATH, 'thumb': ICON_PATH})
    url = build_url({'action': 'list_channels'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    
    # ערוצים ישראליים (קיצור דרך)
    list_item = xbmcgui.ListItem(label="ערוצים ישראליים")
    list_item.setArt({'icon': ICON_PATH, 'thumb': ICON_PATH})
    url = build_url({'action': 'israel_channels'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    
    # ערוצי ספורט (קיצור דרך)
    list_item = xbmcgui.ListItem(label="ערוצי ספורט")
    list_item.setArt({'icon': ICON_PATH, 'thumb': ICON_PATH})
    url = build_url({'action': 'sport_channels'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

def router(paramstring):
    """נתב לפעולות השונות"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    
    if params:
        action = params.get('action')
        
        if action == 'list_channels':
            list_channels()
        elif action == 'search':
            search_channels()
        elif action == 'countries_menu':
            show_countries_menu()
        elif action == 'show_country':
            show_country_channels(params.get('country', ''))
        elif action == 'israel_channels':
            show_israel_channels()
        elif action == 'sport_channels':
            show_sport_channels()
        elif action == 'play_direct':
            play_direct(params['url'], params['name'])
        else:
            main_menu()
    # else:
        # main_menu()

if __name__ == '__main__':
    router(sys.argv[2][1:])