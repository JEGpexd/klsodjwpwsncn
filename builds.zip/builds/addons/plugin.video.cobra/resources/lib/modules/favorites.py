# -*- coding: utf-8 -*-
from caches.favorites_cache import favorites
from modules.settings import ignore_articles, page_limit, paginate
from modules.utils import sort_for_article, paginate_list,get_setting

def get_favorites(media_type, page_no):
    data = favorites.get_favorites(media_type)
    data = sort_for_article(data, 'title', ignore_articles())

    max_pages = int(get_setting("max_pages_limit", 60))

    # הגנה: אם הרשימה ריקה או page_no גבוה מדי – נוריד ל־1
    if not data:
        return [], 0

    total_items = len(data)
    pages_count = (total_items + max_pages - 1) // max_pages  # ceiling division

    if page_no < 1:
        page_no = 1
    elif page_no > pages_count:
        page_no = pages_count

    page_data, _, total_pages = paginate_list(data, page_no, max_pages, 0)
    return [{'media_id': i['tmdb_id'], 'title': i['title']} for i in page_data], total_pages