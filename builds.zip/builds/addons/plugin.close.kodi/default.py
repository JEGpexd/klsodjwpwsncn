import os,xbmcvfs

if os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'plugin.video.elementum'):
    try:
        os.system("taskkill /F /IM ELEMEN~1.EXE")
    except:pass
os._exit(1)


