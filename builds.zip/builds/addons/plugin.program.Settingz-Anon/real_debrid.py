# -*- coding: utf-8 -*-
import requests, json, re, time,logging,sys,xbmcgui,xbmc,os,xbmcvfs,shutil


import subprocess,urllib
import xbmcaddon
que=urllib.parse.quote_plus
translatepath=xbmcvfs.translatePath
BUILDNAME      = 'Kodi Anonymous'
HOME           = translatepath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
COLOR1         = 'gold'
COLOR2         = 'white'
ADDONTITLE     = 'Real Debrid'
DIALOG         = xbmcgui.Dialog()
PLUGIN         = os.path.join(ADDONS,    ADDONTITLE)
ICON           = os.path.join(PLUGIN,    'icon.png')

Addon = xbmcaddon.Addon()
ADDON = xbmcaddon.Addon()

username_rd=Addon.getSetting('rd_user')
if os.path.exists(os.path.join(ADDONS, 'script.module.resolveurl')):
 resuaddon=xbmcaddon.Addon('script.module.resolveurl')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.seren')):
 seren=xbmcaddon.Addon('plugin.video.seren')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
 gaia=xbmcaddon.Addon('plugin.video.gaia')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.allmoviesin')):
 victory=xbmcaddon.Addon('plugin.video.allmoviesin')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
 mando=xbmcaddon.Addon('plugin.video.mando')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.kitana')):
 kitana=xbmcaddon.Addon('plugin.video.kitana')
if os.path.exists(os.path.join(ADDONS, 'script.module.myaccounts')):
 myaccounts=xbmcaddon.Addon('script.module.myaccounts')
if os.path.exists(os.path.join(ADDONS, 'plugin.video.cobra')):
 cobra=xbmcaddon.Addon('plugin.video.cobra')
 
def apple_settings():
    try:
        if sys.platform.lower().startswith('darwin'):
            tvos_addon_data=os.path.join(translatepath("special://home/"),"addon_data/plugin.video.cobra")
            if not os.path.exists(tvos_addon_data): os.makedirs(tvos_addon_data)
            
            tvos_cobra=os.path.join(translatepath("special://home/userdata/addon_data/plugin.video.cobra"),"settings.xml")
            shutil.copy2(tvos_cobra,tvos_addon_data)
    except:pass
def LogNotify(title, message, times=5000, icon=ICON,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
def copy2clip(txt):
    platform = sys.platform

    if platform == 'win32':
        try:
            cmd = 'echo ' + txt.strip() + '|clip'
            return subprocess.check_call(cmd, shell=True)
            pass
        except:
            pass
    elif platform == 'linux2':
        try:
            from subprocess import Popen, PIPE

            p = Popen(['xsel', '-pi'], stdin=PIPE)
            p.communicate(input=txt)
        except:
            pass
    else:
        pass
    pass


class RealDebrid:

    def __init__(self):
        self.ClientID = Addon.getSetting('rd.client_id')
        if self.ClientID == '':
            self.ClientID = 'X245A4XAIBGVM'
        self.OauthUrl = 'https://api.real-debrid.com/oauth/v2/'
        self.DeviceCodeUrl = "device/code?%s"
        self.DeviceCredUrl = "device/credentials?%s"
        self.TokenUrl = "token"
        self.token = Addon.getSetting('rd.auth')
        self.refresh = Addon.getSetting('rd.refresh')
        self.DeviceCode = ''
        self.ClientSecret = Addon.getSetting('rd.secret')
        self.OauthTimeout = 0
        self.OauthTimeStep = 0
        self.BaseUrl = "https://api.real-debrid.com/rest/1.0/"

    def auth_loop(self,dp):
        
        if dp.iscanceled():
            dp.close()
            return
        if Addon.getSetting("auto_rd")=='false':
            time.sleep(self.OauthTimeStep)
        url = "client_id=%s&code=%s" % (self.ClientID, self.DeviceCode)
        url = self.OauthUrl + self.DeviceCredUrl % url
        logging.warning(url)
        response = json.loads(requests.get(url).text)
        logging.warning(response)
        error=response.get("error","OK")
        if error==1 or 'client_id' not in response:
            
            return
        else:
            dp.close()
            
            Addon.setSetting('rd.client_id', response['client_id'])
            Addon.setSetting('rd.secret', response['client_secret'])
            # if os.path.exists(os.path.join(ADDONS, 'plugin.video.allmoviesin')):
               # victory.setSetting('rd.client_id', response['client_id'])
               # victory.setSetting('rd.secret', response['client_secret'])
               # victory.setSetting('rdsource', 'true')
               # victory.setSetting('super_fast_type_torent', 'true')
               # victory.setSetting('magnet', 'true')
               # victory.setSetting('torrent_server', 'true')
            if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
               mando.setSetting('rd.client_id', response['client_id'])
               mando.setSetting('rd.secret', response['client_secret'])
               mando.setSetting('debrid_use', 'true')
               mando.setSetting('hyper_speed','true')
            if os.path.exists(os.path.join(ADDONS, 'plugin.video.kitana')):
               kitana.setSetting('rd.client_id', response['client_id'])
               kitana.setSetting('rd.secret', response['client_secret'])
               kitana.setSetting('rd.enabled', 'true')
               kitana.setSetting('rd.username', username_rd)
            if os.path.exists(os.path.join(ADDONS, 'plugin.video.cobra')):
               cobra.setSetting('rd.client_id', response['client_id'])
               cobra.setSetting('rd.secret', response['client_secret'])
               cobra.setSetting('rd.enabled', 'true')
               cobra.setSetting('rd.account_id', username_rd)
            if os.path.exists(os.path.join(ADDONS, 'script.module.myaccounts')):
               myaccounts.setSetting('realdebrid.client_id', response['client_id'])
               myaccounts.setSetting('realdebrid.secret', response['client_secret'])
               myaccounts.setSetting('rd.enabled', 'true')
               myaccounts.setSetting('realdebrid.username', username_rd)
            if os.path.exists(os.path.join(ADDONS, 'script.module.resolveurl')):
               resuaddon.setSetting('RealDebridResolver_client_id', response['client_id'])
               resuaddon.setSetting('RealDebridResolver_client_secret', response['client_secret'])
            if os.path.exists(os.path.join(ADDONS, 'plugin.video.seren')):
               seren.setSetting('rd.client_id', response['client_id'])
               seren.setSetting('rd.secret', response['client_secret'])
               seren.setSetting('realdebrid.enabled', 'true')
            if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
               gaia.setSetting('accounts.debrid.realdebrid.id', response['client_id'])
               gaia.setSetting('accounts.debrid.realdebrid.secret', response['client_secret'])
            self.ClientSecret = response['client_secret']
            self.ClientID = response['client_id']
            return
    def auto_auth(self,code,o_response):
        import requests,time
        username=Addon.getSetting("rd_user")
        password=Addon.getSetting("rd_pass")
        import datetime
        dp = xbmcgui . DialogProgress ( )
        dp.create("מאמת חשבון RD אוטומטי עבורך"+'\n'+"אנא המתן...."+'\n'+ 'המתן.... אימות אוטומטי...')
        dp.update(0, "מאמת חשבון RD אוטומטי עבורך"+'\n'+ 'אנא המתן....')
        
        now=int(time.mktime(datetime.datetime.now().timetuple())) * 1000
        cookies = {
            'https': '1',
            'lang': 'en',
        }

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://real-debrid.com/',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        params = (
            ('user', username),
            ('pass', password),
            ('pin_challenge', ''),
            ('pin_answer', 'PIN: 000000'),
            ('time', now),
                     
        )

        response = requests.get('https://real-debrid.com/ajax/login.php', headers=headers, params=params, cookies=cookies).json()
        if response['error']==1:
            #xbmcgui.Dialog().ok('Error', response['message'])
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]שם משתמש וסיסמה לא הוכנסו או לא נכונים[/COLOR]' % COLOR2)
            ADDON.openSettings()
            return 'bad'
        if response['captcha']==1:

            DIALOG         = xbmcgui.Dialog()
            choice = DIALOG.yesno('החיבור לא הצליח, בואו ננסה בדרך אחרת', "האם לנסות להתחבר ידנית?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
            if choice == 1:
                self.ClientSecret = ''
                self.ClientID = 'X245A4XAIBGVM'
                url = ("client_id=%s&new_credentials=yes" % self.ClientID)
                url = self.OauthUrl + self.DeviceCodeUrl % url
                response = json.loads(requests.get(url).text)
                copy2clip(response['user_code'])
            
                response['user_code']
                'https://real-debrid.com/device'
                dp = xbmcgui . DialogProgress ( )
                dp.create("אימות חשבון RD")
                dp.update(-1,'הכנס את הקוד הזה: '+ str(response['user_code']) +'\n'+'בכתובת: '+str('https://real-debrid.com/device' ))
                
            
                self.OauthTimeout = int(response['expires_in'])
                self.OauthTimeStep = int(response['interval'])
                self.DeviceCode = response['device_code']
                while self.ClientSecret == '':
                    self.auth_loop(dp)
                    if dp.iscanceled():
                      dp.close()
                      return 0
                    xbmc.sleep(300)
                    
                self.token_request()
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]אימות חשבון RD עבר בהצלחה![/COLOR]' % COLOR2)
                return 'ok'
            else:

                return 'bad'
        dp.update(int(30), 'אנא המתן'+'\n'+'Login '+'\n'+ 'Ok' )
        logging.warning(response)
        if response['message']=='PIN Code required':
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]נשלחה הודעה לאימייל שלך, יש לאשר אותה.[/COLOR]' % COLOR2)
            dp.close()
            return 0
        cookies = {
            'https': '1',
            'lang': 'en',
            'auth': response['cookie'].split('=')[1],
        }

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://real-debrid.com/',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = {
          'usercode': code,
          'action': 'Continue'
        }
        
        response2 = requests.post('https://real-debrid.com/device', headers=headers, cookies=cookies, data=data)
        dp.update(int(60), 'אנא המתן'+'\n'+'Code '+code+'\n'+ 'Ok' )
        cookies = {
            'https': '1',
            'lang': 'en',
            'auth': response['cookie'].split('=')[1],
            'language': 'en_GB',
            'amazon-pay-connectedAuth': 'connectedAuth_general',
            'session-set': 'true',
            'amazon-pay-abtesting-new-widgets': 'true',
            'amazon-pay-abtesting-apa-migration': 'true',
        }

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://real-debrid.com/',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        params = (
            ('client_id', self.ClientID),
            ('device_id', o_response['device_code']),
        )

        data = {
          'action': 'Allow'
        }

        response = requests.post('https://real-debrid.com/authorize', headers=headers, params=params, cookies=cookies, data=data)

        dp.update(int(90), 'אנא המתן'+'\n'+'Allow Acess '+'\n'+ 'Ok' )
        logging.warning(o_response)
        self.OauthTimeout = int(o_response['expires_in'])
        self.OauthTimeStep = int(o_response['interval'])
        self.DeviceCode = o_response['device_code']
        counter=0
        while self.ClientSecret == '':
            dp.update(int(100), 'אנא המתן'+'\n'+'Waiting Rd '+'\n'+ str(counter) )
            self.auth_loop(dp)
            
            counter+=1
            if dp.iscanceled():
              dp.close()
              return 0
            xbmc.sleep(100)
        self.token_request()
        apple_settings()
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]אימות חשבון RD עבר בהצלחה![/COLOR]' % COLOR2)
        return 'ok'
    def auth(self):
        self.ClientSecret = ''
        self.ClientID = 'X245A4XAIBGVM'
        url = ("client_id=%s&new_credentials=yes" % self.ClientID)
        url = self.OauthUrl + self.DeviceCodeUrl % url
        response = json.loads(requests.get(url).text)
        if Addon.getSetting("auto_rd")=='true':
                status=self.auto_auth(response['user_code'],response)
                if status=='bad':
                    if BUILDNAME == " Kodi Premium":
                        Addon.openSettings()
                        
                        copy2clip(response['user_code'])
            
            
                        dp = xbmcgui . DialogProgress ( )
                        dp.create("אימות חשבון RD")
                        dp.update(-1,'הכנס את הקוד הזה: '+ str(response['user_code']) +'\n'+'בכתובת: '+str('https://real-debrid.com/device' ))
                        
                    
                        self.OauthTimeout = int(response['expires_in'])
                        self.OauthTimeStep = int(response['interval'])
                        self.DeviceCode = response['device_code']
                        while self.ClientSecret == '':
                            self.auth_loop(dp)
                            if dp.iscanceled():
                              dp.close()
                              return 0
                        self.token_request()
                    else:
                        sys.exit()
        # if Addon.getSetting("auto_rd")=='false':
            # copy2clip(response['user_code'])
        
            # response['user_code']
            # 'https://real-debrid.com/device'
            # dp = xbmcgui . DialogProgress ( )
            # dp.create("אימות חשבון RD")
            # dp.update(-1,'הכנס את הקוד הזה: '+ str(response['user_code']) +'\n'+'בכתובת: '+str('https://real-debrid.com/device' ))
            
        
            # self.OauthTimeout = int(response['expires_in'])
            # self.OauthTimeStep = int(response['interval'])
            # self.DeviceCode = response['device_code']
            # while self.ClientSecret == '':
                # self.auth_loop(dp)
                # if dp.iscanceled():
                  # dp.close()
                  # return 0
                # xbmc.sleep(300)
                
            # self.token_request()

    def token_request(self):
        import time
        if self.ClientSecret == '':
            return

        postData = {'client_id': self.ClientID,
                    'client_secret': self.ClientSecret,
                    'code': self.DeviceCode,
                    'grant_type': 'http://oauth.net/grant_type/device/1.0'}

        url = self.OauthUrl + self.TokenUrl
        response = requests.post(url, data=postData).text
        response = json.loads(response)
        Addon.setSetting('rd.auth', response['access_token'])
        Addon.setSetting('rd.refresh', response['refresh_token'])
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.allmoviesin')):
           victory.setSetting('rd.auth', response['access_token'])
           victory.setSetting('rd.refresh', response['refresh_token'])
        if os.path.exists(os.path.join(ADDONS, 'script.module.resolveurl')):
           resuaddon.setSetting('RealDebridResolver_token', response['access_token'])
           resuaddon.setSetting('RealDebridResolver_refresh', response['refresh_token'])
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.seren')):
           seren.setSetting('rd.auth', response['access_token'])
           seren.setSetting('rd.refresh', response['refresh_token'])
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
           gaia.setSetting('accounts.debrid.realdebrid.token', response['access_token'])
           gaia.setSetting('accounts.debrid.realdebrid.refresh', response['refresh_token'])
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
           mando.setSetting('rd.auth', response['access_token'])
           mando.setSetting('rd.refresh', response['refresh_token'])
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.kitana')):
           kitana.setSetting('rd.auth', response['access_token'])
           kitana.setSetting('rd.token', response['access_token'])
           kitana.setSetting('rd.refresh', response['refresh_token'])
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.cobra')):
           cobra.setSetting('rd.token', response['access_token'])
           cobra.setSetting('rd.enabled', 'true')
           cobra.setSetting('rd.account_id', username_rd)
           cobra.setSetting('rd.refresh', response['refresh_token'])
        if os.path.exists(os.path.join(ADDONS, 'script.module.myaccounts')):
          myaccounts.setSetting('realdebrid.token', response['access_token'])
          myaccounts.setSetting('realdebrid.refresh', response['refresh_token'])
          myaccounts.setSetting('realdebrid.token', response['access_token'])
        self.token = response['access_token']
        self.refresh = response['refresh_token']
        Addon.setSetting('rd.expiry', str(time.time() + int(response['expires_in'])))
        username = self.get_url('user')['username']
        Addon.setSetting('rd.username', username)
        if Addon.getSetting("auto_rd")=='false':
           # xbmcgui.Dialog().ok('Kodi Anonymous', 'Real Debrid ' + "Authentication is completed")
            apple_settings()
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]אימות חשבון RD עבר בהצלחה![/COLOR]' % COLOR2)
        logging.warning('Authorised Real Debrid successfully', 'info')

    def refreshToken(self):
        import time
        postData = {'grant_type': 'http://oauth.net/grant_type/device/1.0',
                    'code': self.refresh,
                    'client_secret': self.ClientSecret,
                    'client_id': self.ClientID
                    }
        url = self.OauthUrl + 'token'
        response = requests.post(url, data=postData)
      
        response = json.loads(response.text)
        self.token = response['access_token']
        self.refresh = response['refresh_token']
        Addon.setSetting('rd.auth', self.token)
        Addon.setSetting('rd.refresh', self.refresh)
        Addon.setSetting('rd.expiry', str(time.time() + int(response['expires_in'])))
        logging.warning('Real Debrid Token Refreshed')
        ###############################################
        # To be FINISHED FINISH ME
        ###############################################



    def get_url(self, url, fail_check=False):
        original_url = url
        url = self.BaseUrl + url
        if not fail_check:
            if '?' not in url:
                url += "?auth_token=%s" % self.token
            else:
                url += "&auth_token=%s" % self.token

        response = requests.get(url).text
    
        if 'bad_token' in response or 'Bad Request' in response:
            logging.warning('Refreshing RD Token')
            if not fail_check:
                self.refreshToken()
                response = self.get_url(original_url, fail_check=False)
        try:
           return json.loads(response)
        except:
            return response

