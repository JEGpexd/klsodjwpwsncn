# -*- coding: utf-8 -*-
import xbmc,xbmcaddon
from datetime import date, datetime, timedelta
Addon = xbmcaddon.Addon()
AUTONEXTRUN    = Addon.getSetting("next_backup")
AUTOFEQ        = Addon.getSetting('which_day')
AUTOFEQ        = int(AUTOFEQ) if AUTOFEQ.isdigit() else 1
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
TWODAYS        = TODAY + timedelta(days=2)
THREEDAYS      = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)

def set_buffer():
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"filecache.readfactor","value":1000}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"filecache.buffermode","value":2}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"filecache.chunksize","value":131072}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"filecache.memorysize","value":128}}')
def telegram_backup():
    service = False

    days = [TODAY, TOMORROW,TWODAYS, THREEDAYS, ONEWEEK]
    feq = int(float(AUTOFEQ))
    if AUTONEXTRUN <= str(TODAY) or feq == 0:
        service = True
        next_run = days[feq]
        Addon.setSetting('next_backup', str(next_run))
    
    if service == True:

      
      xbmc.executebuiltin("RunPlugin(plugin://plugin.program.Settingz-Anon?mode=332&url=www)")
from time import time
end_pause = time()+30
monitor=xbmc.Monitor()
wait_for_abort = monitor.waitForAbort
while not monitor.abortRequested():
    while time() < end_pause: wait_for_abort(1)
    # set_buffer()
    if len(Addon.getSetting("user_name"))>0:
        telegram_backup()
        
    break
# try:
    # telemedia=xbmcaddon.Addon('plugin.video.telemedia')
    # if telemedia.getSetting('p_mod')=='true':
        # xbmc.executebuiltin("Skin.SetBool(live_tv,true)")
# except:pass