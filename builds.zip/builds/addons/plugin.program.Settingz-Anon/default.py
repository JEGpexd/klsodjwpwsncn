# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,re,xbmcplugin,sys, xbmcvfs
import json
import shutil,glob
import time,subprocess
from shutil import copyfile
import platform,logging
import base64
from resources.log import logsend
from resources.send_m import send_info

Addon = xbmcaddon.Addon()
translatepath=xbmcvfs.translatePath
from urllib.request import urlopen
from urllib.request import Request
que=urllib.parse.quote_plus
url_encode=urllib.parse.urlencode
unque=urllib.parse.unquote_plus


HOME           = translatepath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
__PLUGIN_PATH__ = Addon.getAddonInfo('path')
localizedString = Addon.getLocalizedString 
try:
    user_dataDir = translatepath(Addon.getAddonInfo("profile")).decode("utf-8")
except:
       user_dataDir = translatepath(Addon.getAddonInfo("profile"))

COLOR1         = 'yellow'
COLOR2         = 'white'
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'

try:
    wiza = xbmcaddon.Addon('plugin.program.Anonymous')
    r=wiza.getSetting("action")
    HARDWAER         = r
except:
    HARDWAER         = 'no_wizard'
TMDB_NEW_API = 'aG9qaw=='
TMDB_NEW_API2 = 'bG9qaw=='
ADDONTITLE='Anonymous TV'
iconx = Addon.getAddonInfo('icon')
fanart = Addon.getAddonInfo('fanart')
DIALOG         = xbmcgui.Dialog()
FANART         = fanart
ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108


# import requests,random,logging
# resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
# listen_port=resuaddon.getSetting('port')
# num=random.randint(1,1001)


# data={'type':'td_send',
             # 'info':json.dumps({'@type': 'getActiveSessions', '@extra': num})
             # }
# event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
# count=0
# for i in event2['sessions']:
    # count+=1
    # if 'ch' in i['device_model'] or 'rom'in i['device_model']:
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous',i['device_model'])))





def LogNotify(title, message, times=3500, icon=iconx,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)

code_link='empty'
def read_skin(table_name):
    from resources.modules.firebase import firebase
    fire = firebase.FirebaseApplication('https://zxcsd-3bae5-default-rtdb.firebaseio.com', None)
    result = fire.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def telemedia_vip(table_name):
    from resources.modules.firebase import firebase
    fire = firebase.FirebaseApplication('https://telemedia-vip-default-rtdb.firebaseio.com', None)
    result = fire.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def readcode():
    all_db=telemedia_vip('telecode')
    data=[]
    resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
    user= resuaddon.getSetting("user")
    for itt in all_db:
        items=all_db[itt]
        data.append((items['pin']))
    for pin in data:
       if pin==user.lower():
        return True
def get_pincode(code_link):
    #VIP
    stop_time = time.time() + 600
    while(code_link=='empty' or code_link==None):
          LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Telemedia VIP'),'[COLOR %s]המתן לתגובה מ Anonymous TV...[/COLOR]' % COLOR2)
          code_link=readcode()
          if time.time() > stop_time:
            code_link=False
    return code_link
def read_firebase(table_name):
    from resources.modules.firebase import firebase
    firebase = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def write_firebase_rd(r,p,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'r_user':r,'r_pass':p})
    return 'OK'
def write_firebase_trakt(u,p,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'r_user':u,'r_pass':p})
    return 'OK'
def write_firebase_iptv(m3u,epg,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'m3u':m3u,'epg':epg})
    return 'OK'
def write_favourite(file_data,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'favourite':file_data})
    return 'OK'
def write_skin(file_data,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'skin':file_data})
    return 'OK'
def write_guisettings(file_data,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'guisettings':file_data})
    return 'OK'
def delete_firebase(table_name,record):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)
    result = fb_app.delete(table_name, record)
    return 'OK'
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+unque(url)+"&mode="+str(mode)+"&name="+unque(name)+"&iconimage="+unque(iconimage)+"&fanart="+unque(fanart)+"&description="+unque(description)
        ok=True
        try:
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        except:
            liz=xbmcgui.ListItem(name)
            liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok
def contact_wiz(msg=""):
    class MyWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.title = THEME3 % kwargs["title"]
            self.image = kwargs["image"]
            self.fanart = kwargs["fanart"]
            self.msg = THEME2 % kwargs["msg"]

        def onInit(self):
            self.fanartimage = 101
            self.titlebox = 102
            self.imagecontrol = 103
            self.textbox = 104
            self.scrollcontrol = 105
            self.closebutton = 106
            self.showdialog()

        def showdialog(self):
            self.getControl(self.imagecontrol).setImage(self.image)
            self.getControl(self.fanartimage).setImage(self.fanart)
            self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
            self.getControl(self.textbox).setText(self.msg)
            self.getControl(self.titlebox).setLabel(self.title)
            self.setFocusId(self.closebutton)
        def onClick(self, controlId):
            if   controlId == self.closebutton: self.close()
        def onAction(self,action):
            if   action == self.closebutton: self.close()
            elif   action == ACTION_PREVIOUS_MENU: self.close()
            elif action == ACTION_NAV_BACK: self.close()
    plugin = xbmcaddon.Addon('plugin.program.Anonymous')
    dragon= plugin.getSetting("dragon")
    if dragon=='true':
        cw = MyWindow( "ContactDragon.xml" , Addon.getAddonInfo('path'), 'DefaultSkin', title='DRAGON TV', fanart=FANART, image='', msg=msg)
    else:
        cw = MyWindow( "Contact.xml" , Addon.getAddonInfo('path'), 'DefaultSkin', title='ANONYMOUS TV', fanart=FANART, image='', msg=msg)
    cw.doModal()
    del cw

def addDir2(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+unque(url)+"&mode="+str(mode)+"&name="+unque(name)
    ok=True
    try:
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    except:
        liz=xbmcgui.ListItem(name)
        liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
    liz.setInfo( type="Audio", infoLabels={ "Title": name } )
    if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok
	

def  buffer():
     addDir2("[COLOR white]התקנת באפר אוטומטי לפי נתוני מכשיר[/COLOR]",'plugin.',39,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","התקנת באפר אוטומטי לפי נתוני מכשיר")
     addDir2("[COLOR white]הגדר באפר עד זכרון 1.5 ראם[/COLOR]",'plugin.',11,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר באפר עד זכרון 1.5 ראם")
     addDir2("[COLOR white]הגדר באפר עד 2 ראם[/COLOR]",'plugin.',20,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר באפר עד 2 ראם")
     addDir2("[COLOR white]הגדר באפר מ 3 ראם ומעלה[/COLOR]",'plugin.',21,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר באפר מ 3 ראם ומעלה") 
     addDir2("[COLOR white]הגדר באפר למכשירי Mibox[/COLOR]",'plugin.',25,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר באפר למכשירי Mibox")
     addDir2("[COLOR white]חזרה לבאפר ברירת מחדל[/COLOR]",'plugin.',33,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","החזרה לבאפר ברירת מחדל")

def  rd_trakt_menu():
     addDir2("הגדר חשבון Telemedia VIP",'plugin.',302,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר חשבון Telemedia")
     addDir2("הגדר חשבון אישי Telemedia",'plugin.',344,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר חשבון Telemedia")
     # addDir2("הגדר נתיב הורדה לטלמדיה",'plugin.',341,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר נתיב הורדה לטלמדיה")
     addDir2("איפוס חשבון Telemedia",'plugin.',70,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","אפס חשבון Telemedia")
     
     addDir2("הגדר חשבון RD",'plugin.',183,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר חשבון RD")
     addDir2("אפס חשבון RD",'plugin.',184,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","אפס חשבון RD")
     addDir2("הגדר חשבון Trakt",'plugin.',298,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר חשבון Trakt")
     addDir2("אפס חשבון Trakt",'plugin.',299,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","אפס חשבון Trakt")
     addDir2("הגדר חשבון IPTV",'plugin.',291,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר חשבון IPTV")
     addDir2("הגדר חשבון Dragon",'plugin.',340,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר חשבון Dragon")
     addDir2("הגדר נעילה",'plugin.',305,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר נעילה")
     addDir2("הוסף מאגר קבוצות לחשבון הטלמדיה",'plugin.',345,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","אפס חשבון Telemedia")
     
def user_setting_menu():
     addDir2("הצג תוכן למבוגרים",'plugin.',338,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הצג תוכן למבוגרים")
     addDir2("הסתר תוכן למבוגרים",'plugin.',339,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הסתדר תוכן למבוגרים")
     addDir2("הגדר תיזמון חלון הפרק הבא",'plugin.',186,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר תיזמון חלון הפרק הבא")

     addDir2("אפשרויות בנגן",'plugin.',182,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","אפשרויות בנגן")
     addDir2("הגדר ערוצים עידן פלוס",'plugin.',295,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר ערוצים עידן פלוס")
     addDir3("התקנת באפר",'plugin.',51,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","התקנת באפר")
     addDir2("בטל או אפשר וידגטים",'plugin.',80,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדר בטל או אפשר וידגטים")
     addDir3("תיקון תצוגת סקין",'plugin.',23,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","תיקון תצוגת סקין")
     addDir2("הסר קבוצות שנחסמו מטלמדיה",'plugin.',343,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הסר קבוצות שנחסמו מטלמדיה")
def fix_setting_menu():
     addDir3("תיקון תצוגת סקין",'plugin.',23,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","תיקון תצוגת סקין")
     addDir2("איפוס טלמדיה",'plugin.',70,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","איפוס טלמדיה")

def telegram_save_menu():
    vip=xbmcaddon.Addon('plugin.video.telemedia')
    import random,requests

    listen_port=vip.getSetting('port')
    num=random.randint(1,1001)
    data={'type':'td_send',
                 'info':json.dumps({'@type': 'getOption','name':'my_id', '@extra': num})
                 }
    event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    id=event2['value']

    if '1229060184'== id or '838481324'== id or '5667480303'== id or '5771387214'== id or '5984604232'== id or '5941680786'== id or '6022195851'== id or '6217448590'== id:

             addDir2("גיבוי",'plugin.',330,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","גיבוי")
             addDir2("שחזור",'plugin.',327,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","שחזור")
             addDir2("הגדרות",'plugin.',303,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדרות")
             addDir2("אפס את שם המכשיר",'plugin.',331,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","אפס הגדרות")

    else:

         if not len(Addon.getSetting("bot_id"))>0:
             addDir2("בחר ערוץ לגיבוי",'plugin.',329,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","בחר ערוץ לגיבוי")
         else:
             addDir2("גיבוי",'plugin.',330,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","גיבוי")
             addDir2("שחזור",'plugin.',327,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","שחזור")
             addDir2("הגדרות",'plugin.',303,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדרות")
             addDir2("אפס הגדרות",'plugin.',331,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","אפס הגדרות")

def main_menu():
     addDir3("הגדרת חשבון",'plugin.',320,__PLUGIN_PATH__ + "/icon.png",__PLUGIN_PATH__ + "fanart.jpg","חשבון RD ו TRAKT")
     addDir3("הגדרות משתמש",'plugin.',321,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדרות משתמש")
     addDir3("גיבוי ושחזור",'plugin.',326,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","גיבוי ושחזור")
     

     addDir2("הגדרות",'plugin.',303,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","הגדרות")
     addDir2("בדיקת מהירות",'plugin.',40,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","בדיקת מהירות")

     addDir2("שלח לוג",'plugin.',185,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","שלח לוג")
     addDir2("בדיקה",'plugin.',356,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","שלח לוג")
def setNew(new, value):
	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)

		response = xbmc.executeJSONRPC(query)
	except:
		pass
	return None
def getOld(old):
	try:
		old = '"%s"' % old 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
		
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if 'result' in response:
			if 'value' in response['result']:
				return response ['result']['value'] 
	except:
		pass
	return None
def swapSkins(skin, title="Error"):
	old = 'lookandfeel.skin'
	value = skin
	current = getOld(old)
	new = old
	setNew(new, value)
	x = 0
	while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
		x += 1
		xbmc.sleep(1)
	if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
		xbmc.executebuiltin('SendClick(11)')
	return True
def function10():
   xbmc.executebuiltin( "RunPlugin(plugin://plugin.program.Anonymous/?mode=kodi17fix)" )
def function11():
  xbmc.executebuiltin("ReloadSkin()")
def rebootfromnand():
    nandscript = '/usr/sbin/rebootfromnand'
    
    if os.path.exists(nandscript):
        xbmcgui.Dialog().notification('Success!', 'Reboot to Android TV!', xbmcgui.NOTIFICATION_INFO)
        subprocess.call([nandscript])
        xbmc.sleep(300)
        xbmc.executebuiltin('Reboot')
    else:
        xbmcgui.Dialog().notification('Error!', 'rebootfromnand not available!', xbmcgui.NOTIFICATION_ERROR)
def set_id_firebase():
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מזהה ID')
    keyboard.doModal()
    if keyboard.isConfirmed():
     search_entered = keyboard.getText()
     
     try:
        Addon.setSetting('firebase',search_entered)
        all_db=read_firebase('table_name')
        xbmc.executebuiltin('Container.Refresh')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
            sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
            sync_tele.setSetting('firebase',search_entered)
            sync_tele.setSetting('sync_mod','true')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
            sync_mando=xbmcaddon.Addon('plugin.video.mando')
            sync_mando.setSetting('firebase',search_entered)
            sync_mando.setSetting('sync_mod','true')
     except:
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Firebase'),'[COLOR %s]לא קיים שם משתמש כזה ב Firebase[/COLOR]' % COLOR2)
        Addon.setSetting('firebase','')
def set_name_telegram_backup():

    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס שם לגיבוי')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           Addon.setSetting('user_name', str(search_entered))
           xbmc.executebuiltin('Container.Refresh')

def unzip(file,path):
    import zipfile
    zip_file = file
    ptp = 'Masterpenpass'
    zf=zipfile.ZipFile(zip_file)
    listOfFileNames = zf.namelist()
    with zipfile.ZipFile(zip_file, 'r') as zipObj:
       zipObj.extractall(path)

def set_bot_id():
    import random,requests
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    num=random.randint(0,60000)

    dp = xbmcgui . DialogProgress ( )
    dp.create('Please Wait...','Adding Groups')
    dp.update(0, 'Please Wait...' )
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '1000', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
    names=[]
    ids=[]
    if 'status' in event:
        xbmcgui.Dialog().ok('Error occurred',event['status'])
        exit_now=1
    if exit_now==0:
       
        counter=0
        counter_ph=10000
        j_enent_o=(event)
        zzz=0
        items=''

        for items in j_enent_o['chat_ids']:
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':counter})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            order=event['positions'][0]['order']
            if dp.iscanceled():
                          dp.close()
                          break
            j_enent=(event)
            dp.update(int(((zzz* 100.0)/(len(j_enent_o['chat_ids']))) ), j_enent['@type'] )
            zzz+=1
            if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                names.append(j_enent['title'])
                ids.append(items)
    selected_group_id=-1
    if len(names)>0:
        ret = xbmcgui.Dialog().select("בחר ערוץ בו ישמר המידע", names)
        if ret==-1:
            sys.exit()
        else:
            selected_group_id=ids[ret]
        if selected_group_id!=-1:
            Addon.setSetting('bot_id',str(ids[ret]))
            
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ערוץ הגיבוי הוגדר![/COLOR]' % COLOR2)
    xbmc.executebuiltin('Container.Refresh')
def compress(url):
    import zlib
    data = url
    json_str = base64.urlsafe_b64encode(zlib.compress(data.encode('utf-8'))).decode()
    decoded='&'+json_str+'$'
    
    return decoded
def decompress(url):
    import zlib
    data = url
    data.replace('$','').replace('&','')

    json_str = zlib.decompress(base64.urlsafe_b64decode(data)).decode('utf-8')
   
    return json_str
    
def create_and_set_chat_for_backup():
    import random,requests,logging
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    num=random.randint(1,1001)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '1000', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    xbmc.sleep(1000)
    data={'type':'td_send',
         'info':json.dumps({'@type': 'searchChats', 'query': 'Kodi Backup','limit':100, '@extra': num})
         }
         
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    if len(event['chat_ids'])>0:
        
        for items in event['chat_ids']:
            data={'type':'td_send',
                     'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':num})
                     }
                     
            event_in=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

            if event_in['title']=='Kodi Backup':
                Addon.setSetting('bot_id',str(items))


    else:
        data={'type':'td_send',
                     'info':json.dumps({'@type': 'createNewSupergroupChat','title':'Kodi Backup','is_channel':True,'message_auto_delete_time':0, '@extra': num})
                     }
        event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchChats', 'query': 'Kodi Backup','limit':100, '@extra': num})
             }
             
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if len(event['chat_ids'])>0:
            
            for items in event['chat_ids']:
                data={'type':'td_send',
                         'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':num})
                         }
                         
                event_in=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

                if event_in['title']=='Kodi Backup':
                    Addon.setSetting('bot_id',str(items))
                data={'type':'td_send',
                             'info':json.dumps({'@type': 'setChatNotificationSettings','chat_id':items,'notification_settings':{'@type': 'chatNotificationSettings','mute_for':1911111111}, '@extra': num})
                             }
                event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
def backup_telegram(silent='True'):
    if len(Addon.getSetting("user_name"))==0:
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס שם לגיבוי')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               Addon.setSetting('user_name', str(search_entered))
        if search_entered=='':
          return
    import zipfile,random,datetime,os,requests
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    num=random.randint(1,1001)

    if silent=='False':
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מגבה אנא המתן[/COLOR]' % COLOR2)
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    exclude_files = ['xmltv.xml.cache']
    # telemedia
    tele=os.path.join(translatepath('special://profile/addon_data/plugin.video.telemedia'))

    tele_watched=os.path.join(tele, 'cache_play.db')
    tele_watched_kids=os.path.join(tele, 'database.db')
    #cobra
    cobra=os.path.join(translatepath('special://profile/addon_data/plugin.video.cobra'))
    cobra_settings=os.path.join(cobra, 'settings.xml')
    
    cobra_folder=os.path.join(translatepath('special://profile/addon_data/plugin.video.cobra/databases'))
    cobra_favourite=os.path.join(cobra_folder, 'favourites.db')
    cobra_watched=os.path.join(cobra_folder, 'watched.db')
    
    
    settingz=os.path.join(translatepath('special://profile/addon_data/plugin.program.Settingz-Anon'))
    databasesettingz=os.path.join(settingz, 'settings.xml')
    keymap=os.path.join(translatepath('special://profile/keymaps'))


    # iptv simple
    iptvsimple=os.path.join(translatepath('special://profile/addon_data/pvr.iptvsimple'))
    
    resolveurl=os.path.join(translatepath('special://profile/addon_data/script.module.resolveurl'))
    resolveurlsettings=os.path.join(resolveurl, 'settings.xml')

    skin=os.path.join(translatepath('special://profile/addon_data/skin.anonymoustv'))
    skin_settings=os.path.join(skin, 'settings.xml')

    favourites=os.path.join(translatepath('special://profile'))
    favouritesfile=os.path.join(favourites, 'favourites.xml')

    guisettings=os.path.join(translatepath('special://profile'))
    guisettingsfile=os.path.join(guisettings, 'guisettings.xml')

    Database=os.path.join(translatepath('special://profile/Database'))
    kodi_watched=os.path.join(Database, 'MyVideos131.db')



    
    # wiz=xbmcaddon.Addon('plugin.video.telemedia')
    wiz=xbmcaddon.Addon('plugin.program.Anonymous')
    
    backup_name=Addon.getSetting("user_name")


    selected_group_id=Addon.getSetting("bot_id")
    # username=Addon.getSetting("user_name")
    username=wiz.getSetting("user")
    zp_file=os.path.join(user_dataDir,str(time.strftime("%d/%m/%Y").replace('/','.')+' שעה '+str(time.strftime("%H/%M").replace('/',':')+' מכשיר - '+backup_name +'.zip')))
    if os.path.isfile(zp_file):
        os.remove(zp_file)
    zipf = zipfile.ZipFile(zp_file , mode='w')
    
    dirname=os.path.join(translatepath('special://profile'))


    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(tele_watched,tele_watched[len(dirname):])
        except:pass
        try:
         zipf.write(tele_watched_kids,tele_watched_kids[len(dirname):])
        except:pass
        
        try:
         zipf.write(cobra_watched,cobra_watched[len(dirname):])
        except:pass
        
        try:
         zipf.write(kodi_watched,kodi_watched[len(dirname):])
        except:pass



    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(resolveurlsettings,resolveurlsettings[len(dirname):])
        except:pass
        try:
         zipf.write(cobra_settings,cobra_settings[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_favo")=='true':
        try:
         zipf.write(favouritesfile,favouritesfile[len(dirname):])
        except:pass
        try:
         zipf.write(cobra_favourite,cobra_favourite[len(dirname):])
        except:pass

    if Addon.getSetting("guisettings")=='true':
        try:
         zipf.write(guisettingsfile,guisettingsfile[len(dirname):])
        except:pass


    if Addon.getSetting("sync_iptv")=='true':
       for base, dirs, files in os.walk(iptvsimple):
        files[:] = [f for f in files if f not in exclude_files]
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass


    if Addon.getSetting("sync_setting")=='true':
        try:
            zipf.write(skin_settings,skin_settings[len(dirname):])
        except:pass


    try:
     zipf.write(databasesettingz,databasesettingz[len(dirname):])
    except:pass
    
    for base, dirs, files in os.walk(keymap):
       for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    


    zipf.close()

    num2=random.randint(0,60000)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num2})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
    try:
        if 'status' in event:
            xbmcgui.Dialog().ok('Error occurred',event['status'])
            exit_now=1
    except:pass
     # {'@type':'inputMessageText','text': {'@type':'FormattedText','text': '222'}
    data={'type':'td_send',
                 'info':json.dumps({'@type': 'sendMessage','chat_id': selected_group_id,'input_message_content': {'@type':'inputMessageDocument','document': {'@type':'inputFileLocal','path': zp_file},'caption': {'@type':'FormattedText','text': username}},'@extra': 1 })
                 }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

    try:
        xbmc.sleep(1000)
        if os.path.isfile(zp_file):
            os.remove(zp_file)
    except:
        pass
    if silent=='False':
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]גיבוי הסתיים[/COLOR]' % COLOR2)
    else:
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]בוצע גיבוי למידע שלך.[/COLOR]' % COLOR2)

def restore_backup_telegram(first_builds_restore=''):
    import requests,random,os
    DIALOG         = xbmcgui.Dialog()
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    
    listen_port=resuaddon.getSetting('port')
    cacheFile = os.path.join(user_dataDir, 'cache_play.db')
    zp_file= os.path.join(user_dataDir, 'data.zip')
    wiz=xbmcaddon.Addon('plugin.program.Anonymous')


    create_and_set_chat_for_backup()
    username=wiz.getSetting("user")
    selected_group_id=Addon.getSetting("bot_id")

    num=random.randint(1,1001)
    num2=random.randint(0,60000)
    import logging
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num2})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
    all_n=[]
    all_ids=[]
    count=0
    search_entered=['',compress(username)]
    all_t_links=[]
    if 'status' in event:
        xbmcgui.Dialog().ok('Error occurred',event['status'])
        exit_now=1
    
    for query in search_entered:
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchChatMessages','chat_id':(selected_group_id), 'query': query,'from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
             }

        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if 'messages' not in event:
            xbmc.sleep(5000)
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(selected_group_id), 'query': query,'from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if 'messages' in event:
            for items in event['messages']:

                    
                    file_name=items['content']['document']['file_name']
                    name_id=items['content']['caption']['text']
                    if file_name in all_t_links :
                        continue
                    all_t_links.append(file_name)
                    
                    try:
                        name_id=decompress(name_id)
                    except:
                        name_id=items['content']['caption']['text']

                    count+=1
                    all_n.append(file_name.replace('.zip',''))
                    all_ids.append(str(items['content']['document']['document']['id']))

    if first_builds_restore=='true' and len(all_n)>0:
            choice = DIALOG.yesno(ADDONTITLE, "קיים עבורך מידע לשחזור בענן, האם תרצה לשחזר?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
            if choice == 0:
                return

    else:
          if first_builds_restore=='true' :
                choice = DIALOG.yesno(ADDONTITLE, "האם תרצה לגבות את הנתונים שלך?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]אחר כך[/COLOR][/B]")
                if choice == 1:
                    backup_telegram()

    if len(all_n)>0:
        ret = xbmcgui.Dialog().select("בחר תאריך לשחזור - מספר הגיבויים: "  +str(count), all_n)
        if ret!=-1 :

                data={'type':'download_photo',
                         'info':all_ids[ret]
                         }
                file=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                xbmc.sleep(100)
                dirname=os.path.join(translatepath('special://profile'))
                unzip(file,dirname)
                xbmcvfs.delete(file)
                if not len(Addon.getSetting("user_name"))>0:
                    try:

                        regex=' מכשיר - (.+?)$'
                        mm=re.compile(regex).findall(all_n[ret])[0]
                        m='[COLOR yellow]'+mm+'[/COLOR]'
                        
                        choice = DIALOG.yesno(ADDONTITLE, "האם תרצה להגדיר את שם המכשיר הזה כ - %s ?"%m, yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא, אבחר שם אחר[/COLOR][/B]")
                        if choice == 1:
                            Addon.setSetting("user_name",mm)
                        else:
                            search_entered=''
                            keyboard = xbmc.Keyboard(search_entered, 'הכנס שם למכשיר')
                            keyboard.doModal()
                            if keyboard.isConfirmed():
                                   search_entered = keyboard.getText()
                                   Addon.setSetting('user_name', str(search_entered))
                            if search_entered=='':
                              return
                    except:pass
                if first_builds_restore=='true':
                    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'מומלץ להפעיל את הקודי מחדש.'),'[COLOR %s]שחזור בוצע בהצלחה![/COLOR]' % COLOR2)
                    choice = DIALOG.yesno(ADDONTITLE, "להשלמת השחזור עדיף להפעיל את הקודי מחדש", yeslabel="[B][COLOR WHITE]הפעל מחדש[/COLOR][/B]", nolabel="[B][COLOR white]יותר מאוחר[/COLOR][/B]")
                    if choice == 1:
                      resetkodi('true')
                else:
                    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'מומלץ להפעיל את הקודי מחדש.'),'[COLOR %s]שחזור בוצע בהצלחה![/COLOR]' % COLOR2)
    else:
        if first_builds_restore=='':
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אין מידע לשחזר[/COLOR]' % COLOR2)
    if os.path.isfile(zp_file):
        os.remove(zp_file)
    if Addon.getSetting("guisettings")=='true' or Addon.getSetting("sync_setting")=='true':
        # Addon.setSetting('guisettings','false')
        DP = xbmcgui.DialogProgress()
        DP.create("להלשמת הפעולה הקודי יסגר ","[COLOR orange][B]מסיים פעולות[/B][/COLOR]")
        DP.update(0)
        for s in range(5, -1, -1):
            time.sleep(1)
            DP.update(int((5 - s) / 5.0 * 100),'המערכת תסגר בעוד {0} שניות'.format(s))
            if DP.iscanceled():
                os._exit(1)
                return None, None
        os._exit(1)
    try:
        dp.close()
    except:
        pass

def rd_off():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno('AnonymousTV', "האם לאפס את חשבון Real-Debrid?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        Addon.setSetting('auto_rd','false')
        Addon.setSetting("rd_user",'')
        Addon.setSetting("rd_pass",'')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
            mando = xbmcaddon.Addon('plugin.video.mando')
            mando.setSetting('rd.client_id','')
            mando.setSetting('rd.secret','')
            mando.setSetting('rd.auth','')
            mando.setSetting('rd.refresh','')
            mando.setSetting('debrid_use', 'false')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.kitana')):
            kitana = xbmcaddon.Addon('plugin.video.kitana')
            kitana.setSetting('rd.client_id','')
            kitana.setSetting('rd.secret','')
            kitana.setSetting('rd.enabled','false')
            kitana.setSetting('rd.username', '')
        if os.path.exists(os.path.join(ADDONS, 'script.module.myaccounts')):
           myaccounts = xbmcaddon.Addon('script.module.myaccounts')
           myaccounts.setSetting('realdebrid.client_id', '')
           myaccounts.setSetting('realdebrid.secret', '')
           myaccounts.setSetting('rd.enabled', 'false')
           myaccounts.setSetting('realdebrid.username', '')
        if os.path.exists(os.path.join(ADDONS, 'script.module.resolveurl')):
            resolveurl = xbmcaddon.Addon('script.module.resolveurl')
            resolveurl.setSetting('RealDebridResolver_client_id','')
            resolveurl.setSetting('RealDebridResolver_client_secret','')
            resolveurl.setSetting('RealDebridResolver_token','')
            resolveurl.setSetting('RealDebridResolver_refresh','')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.cobra')):
            cobra = xbmcaddon.Addon('plugin.video.cobra')
            cobra.setSetting('rd.client_id','')
            cobra.setSetting('rd.secret','')
            cobra.setSetting('rd.enabled','false')
            cobra.setSetting('rd.account_id', '')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Real Debrid'),'[COLOR %s]בוטל[/COLOR]' % COLOR2)
def trakt_off():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno('AnonymousTV', "האם לאפס את חשבון Trakt?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        Addon.setSetting('auto_trk','false')
        Addon.setSetting("trk_user", '')
        Addon.setSetting("trk_pass", '')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
            mando = xbmcaddon.Addon('plugin.video.mando')
            mando.setSetting("trakt_expires_at", '')
            mando.setSetting("trakt_access_token", '')
            mando.setSetting("trakt_refresh_token", '')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
            tele = xbmcaddon.Addon('plugin.video.telemedia')
            tele.setSetting("trakt_expires_at", '')
            tele.setSetting("trakt_access_token", '')
            tele.setSetting("trakt_refresh_token",'')
            tele.setSetting('auto_trk', 'false')
        if os.path.exists(os.path.join(ADDONS, 'script.module.myaccounts')):
           myaccounts = xbmcaddon.Addon('script.module.myaccounts')
           myaccounts.setSetting("trakt.expires", '')
           myaccounts.setSetting("trakt.token", '')
           myaccounts.setSetting("trakt.refresh", '')
           myaccounts.setSetting('trakt.username', '')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.kitana')):
           kitana = xbmcaddon.Addon('plugin.video.kitana')
           kitana.setSetting('trakt.token', '')
           kitana.setSetting('trakt.expires', '')
           kitana.setSetting('trakt_user', '')
           kitana.setSetting('trakt_indicators_active', 'false')
           kitana.setSetting('watched_indicators', '0')
        if os.path.exists(os.path.join(ADDONS, 'plugin.video.cobra')):
           cobra = xbmcaddon.Addon('plugin.video.cobra')
           cobra.setSetting('trakt.token', '')
           cobra.setSetting('trakt.refresh', '')
           cobra.setSetting('trakt.expires', '')
           cobra.setSetting('trakt.user', '')
           cobra.setSetting('trakt.indicators_active', 'false')
           cobra.setSetting('watched_indicators', '0')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'TRAKT'),'[COLOR %s]בוטל[/COLOR]' % COLOR2)
def set_folder_telemedia_files():
    telemedia=xbmcaddon.Addon('plugin.video.telemedia')
    directory=telemedia.getSetting('directory_mod')
    path=telemedia.getSetting('movie_download_directory')
    if directory=='true':
        ss='[COLOR lime]'+'מופעל'+'[/COLOR]'
    else:
        ss='[COLOR ffe52b50]'+'כבוי'+'[/COLOR]'
    dialog = xbmcgui.Dialog()
    funcs = (
        set_folder_on,
        set_folder,
        '',
        )
    if directory=='true':
        call = dialog.select('[COLOR yellow]הגדר מיקום הורדת הקבצים[/COLOR]', [
        'מיקום הורדת קבצים: '+ss,
        'הגדר נתיב',
        path,])
        
        if call:
            
            if call < 0:
                return
            func = funcs[call-3]
            try:
                return func()
            except:set_folder_telemedia_files()
        else:
            func = funcs[call]



            return func(),set_folder_telemedia_files()
    else:
        call = dialog.select('[COLOR yellow]הגדר מיקום הורדת הקבצים[/COLOR]', [
        'מיקום הורדת קבצים: '+ss,])
        
        if call:
            
            if call < 0:
                return
            func = funcs[call-1]
            
            return func()
        else:
            func = funcs[call]

            return func(),set_folder_telemedia_files()
    return 
def set_folder_on():
    telemedia=xbmcaddon.Addon('plugin.video.telemedia')
    cobra=xbmcaddon.Addon('plugin.video.cobra')
    directory=telemedia.getSetting('directory_mod')
    if directory=='true':
        telemedia.setSetting('directory_mod','false')
        cobra.setSetting("telemedia_download_directory",'special://profile/addon_data/plugin.video.cobra/Telemedia Downloads/')
        
        ok=xbmcgui.Dialog().yesno(("יש להפעיל את הקודי מחדש לאחר שינוי זה."),('להפעיל מחדש?'))
        if ok:
             os._exit(1)
    else:
        telemedia.setSetting('directory_mod','true')
def set_folder():
        HOME             = translatepath('special://home/')
        telemedia=xbmcaddon.Addon('plugin.video.telemedia')
        cobra=xbmcaddon.Addon('plugin.video.cobra')
        path=telemedia.getSetting('directory_mod')
        if path:
          path = xbmcgui.Dialog().browse(0,"בחר תקייה", 'files')
          telemedia.setSetting("movie_download_directory",path)
          cobra.setSetting("telemedia_download_directory",path)
          ok=xbmcgui.Dialog().yesno(("יש להפעיל את הקודי מחדש לאחר שינוי זה."),('להפעיל מחדש?'))
          if ok:
               os._exit(1)
def delete_blocked_groups():
    p_s= '55555'
    dialog = xbmcgui.Dialog()
    search_entered=''
    keyboard = dialog.numeric(0, 'הכנס סיסמה')
    search_entered = keyboard
    if search_entered==p_s:
        import random,requests
        num=random.randint(0,60000)
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        query=["This message couldn't be displayed on your device due to copyright infringement.","This group is unavailable due to copyright infringement.","This channel is unavailable due to copyright infringement."]
        all_ids=[]
        counter=0
        for i in query:
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchMessages', 'query': i,'offset_message_id':0,'offset_chat_id':0,'limit':1000, '@extra': num})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            for items in event['messages']: 
                if 'text' in items['content']:
                        SS=items['restriction_reason']
                        if "This message couldn't be displayed on your device due to copyright infringement." == SS :
                            if items['chat_id'] in all_ids:
                                continue
                            all_ids.append(items['chat_id'])
                            counter+=1
                            data={'type':'td_send',
                                 'info':json.dumps({'@type': 'leaveChat', 'chat_id': items['chat_id'], '@extra': num})
                                 }
                            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        LogNotify(ADDONTITLE,'הוסרו: '+str(counter)+' ערוצים')
        sys.exit()

def set_nextup():
    kitana=xbmcaddon.Addon('plugin.video.cobra')
    
    play_next=kitana.getSetting('play_next')
    autoscrape_next_episode=kitana.getSetting('autoscrape_next_episode')
    ss='[COLOR ffe52b50]'+'כבוי'+'[/COLOR]'
    autoscrape='[COLOR ffe52b50]'+'כבוי'+'[/COLOR]'
    if play_next=='true':
        ss='[COLOR lime]'+'מופעל'+'[/COLOR]'
    if autoscrape_next_episode=='true':
        autoscrape='[COLOR lime]'+'מופעל'+'[/COLOR]'
    # else:
        # ss='[COLOR red]'+'כבוי'+'[/COLOR]'
        # autoscrape='[COLOR ffe52b50]'+'כבוי'+'[/COLOR]'
    dialog = xbmcgui.Dialog()
    funcs = (
        nextup,
        nextup2,
        nextup30,
        nextup60,
        nextup90,
        nextup120,
        nextup150,
        nextup180,
        nextup210,
        nextup240,

        )
    if play_next=='true':
        call = dialog.select('[COLOR yellow]הגדר זמן הופעת חלון פרק הבא[/COLOR]', [
        'פרק הבא: '+ss,
        # 'מקורות לפרק הבא: '+autoscrape,
        '30 שניות', 
        '60 שניות',
        'דקה וחצי',
        '2 דקות',
        '2 וחצי דקות',
        '3 דקות',
        '3 וחצי דקות',
        '4 דקות',])
        
        if call:
            
            if call < 0:
                return
            func = funcs[call-9]
            
            return func()
        else:
            func = funcs[call]



            return func(),set_nextup()
    elif autoscrape_next_episode=='true':
        call = dialog.select('[COLOR yellow]הגדר זמן הופעת חלון פרק הבא[/COLOR]', [
        'פרק הבא: '+ss,
        # 'מקורות לפרק הבא: '+autoscrape,
        '30 שניות', 
        '60 שניות',
        'דקה וחצי',
        '2 דקות',
        '2 וחצי דקות',
        '3 דקות',
        '3 וחצי דקות',
        '4 דקות',])
        
        if call:
            
            if call < 0:
                return
            func = funcs[call-9]
            
            return func()
        else:
            func = funcs[call]



            return func(),set_nextup()
    else:
        call = dialog.select('[COLOR yellow]הפרק הבא[/COLOR]', [
        'פרק הבא: '+ss,])
        
        if call:
            
            if call < 0:
                return
            func = funcs[call-1]
            
            return func()
        else:
            func = funcs[call]

            return func(),set_nextup()
    return 
def nextup():
 
    kitana=xbmcaddon.Addon('plugin.video.cobra')
    flashstream=xbmcaddon.Addon('plugin.video.flashstream')
    play_next=kitana.getSetting('play_next')


    if play_next=='true':
        kitana.setSetting('play_next','false')
        flashstream.setSetting('enable_next_episode','false')

    else:
        kitana.setSetting('play_next','true')
        kitana.setSetting('autoscrape_next_episode','false')
        flashstream.setSetting('enable_next_episode','true')
def nextup2():
 
    kitana=xbmcaddon.Addon('plugin.video.cobra')
    autoscrape_next_episode=kitana.getSetting('autoscrape_next_episode')
    if autoscrape_next_episode=='true':
        kitana.setSetting('autoscrape_next_episode','false')
    else:
        kitana.setSetting('autoscrape_next_episode','true')
        kitana.setSetting('play_next','false')
        
    set_nextup()
def nextup30():
        flashstream = xbmcaddon.Addon('plugin.video.flashstream')
        flashstream.setSetting('next_ep_trigger','30')
        kitana = xbmcaddon.Addon('plugin.video.cobra')
        kitana.setSetting('autoplay_next_window_percentage','98')

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]30 שניות הוגדר[/COLOR]' % COLOR2)
def nextup60():
        flashstream = xbmcaddon.Addon('plugin.video.flashstream')
        flashstream.setSetting('next_ep_trigger','60')
        kitana = xbmcaddon.Addon('plugin.video.cobra')
        kitana.setSetting('autoplay_next_window_percentage','97')

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]60 שניות הוגדר[/COLOR]' % COLOR2)
def nextup90():
        flashstream = xbmcaddon.Addon('plugin.video.flashstream')
        flashstream.setSetting('next_ep_trigger','90')
        kitana = xbmcaddon.Addon('plugin.video.cobra')
        kitana.setSetting('autoplay_next_window_percentage','96')

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]דקה וחצי הוגדר[/COLOR]' % COLOR2)
def nextup120():
        flashstream = xbmcaddon.Addon('plugin.video.flashstream')
        flashstream.setSetting('next_ep_trigger','120')
        kitana = xbmcaddon.Addon('plugin.video.cobra')
        kitana.setSetting('autoplay_next_window_percentage','95')

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]2 דקות הוגדר[/COLOR]' % COLOR2)
def nextup150():
        flashstream = xbmcaddon.Addon('plugin.video.flashstream')
        flashstream.setSetting('next_ep_trigger','150')
        kitana = xbmcaddon.Addon('plugin.video.cobra')
        kitana.setSetting('autoplay_next_window_percentage','94')

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]2 וחצי דקות הוגדר[/COLOR]' % COLOR2)
def nextup180():
        flashstream = xbmcaddon.Addon('plugin.video.flashstream')
        flashstream.setSetting('next_ep_trigger','180')
        kitana = xbmcaddon.Addon('plugin.video.cobra')
        kitana.setSetting('autoplay_next_window_percentage','93')

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]3 דקות הוגדר[/COLOR]' % COLOR2)
def nextup210():
        flashstream = xbmcaddon.Addon('plugin.video.flashstream')
        flashstream.setSetting('next_ep_trigger','210')
        kitana = xbmcaddon.Addon('plugin.video.cobra')
        kitana.setSetting('autoplay_next_window_percentage','92')

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]3 וחצי דקות הוגדר[/COLOR]' % COLOR2)
def nextup240():
        flashstream = xbmcaddon.Addon('plugin.video.flashstream')
        flashstream.setSetting('next_ep_trigger','240')
        kitana = xbmcaddon.Addon('plugin.video.cobra')
        kitana.setSetting('autoplay_next_window_percentage','91')

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]4 דקות הוגדר[/COLOR]' % COLOR2)



def setrealdebrid():
    z=Addon.getSetting("auto_rd")
    if z == 'false':
     Addon.openSettings()
    import real_debrid
    rd = real_debrid.RealDebrid()
    rd.auth()

def traktsync():
     trakt= Addon.getSetting("auto_trk")
     if trakt == 'false':
       Addon.openSettings()
     import trk_aut

def check_url():
    try:
        x=urlopen('https://www.google.com').read()
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok("Anonymous TV", 'אין חיבור אינטרנט פעיל, ריסט לראוטר עשוי לפתור את הבעיה.')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')



def tele_account_down():

    sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
    sync_tele.setSetting('vip_login2','true')
    stop_time = time.time() + 60
    while 1:
          if sync_tele.getSetting('vip_login2')=='true':
            xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")
            break
          if time.time() > stop_time:
            stop_listen=2
            code_link=''
            break

def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        try:
          dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        except:
          dec_c = chr((256 + (enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):

    value=decode("7643",url)
    return int(value)

def getHwAddr(ifname ):
   
   if xbmc .getCondVisibility ('system.platform.android'):
      try:
         import subprocess
         Installed_APK =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()
         mac =re .compile ('link/ether (.+?) brd').findall (str (Installed_APK ))
         n =0 
         for match in mac :
          if mac !='00:00:00:00:00:00':
              mac_address =match
              n =n +int (mac_address .replace (':',''),16 )
              break
      except:
           n =0 
           from uuid import getnode as get_mac
           n =get_mac()
   elif xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
                break
   else :
       n =0 
       from uuid import getnode as get_mac
       n =get_mac()

   try:
    return n
   except: pass
def disply_hwr2(info=''):
    try:
        from datetime import date

        today = date.today()
        zz=str(today).split('-')[2]
        # zz=str(time.strftime("%H/%M").replace('/','-')).split('-')[0]
        my_tmdb=tmdb_list(TMDB_NEW_API)
        num=str((getHwAddr('eth0'))*my_tmdb)
        new_num=(num[1]+num[2]+zz)
    except:
        new_num='0000'


def resetkodi(first_builds_restore=''):
        DP = xbmcgui.DialogProgress()
        if xbmc.getCondVisibility('system.platform.windows'):
            if first_builds_restore=='':
                # DP.create("מבצע הפעלה מחדש", "אנא המתן 5 שניות"+'\n'+ ''+'\n'+
                # "[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה[/B][/COLOR]")
                DP.create("מבצע הפעלה מחדש", 
                "[COLOR yellow][B]אנא המתן...[/B][/COLOR]")
            else:
                DP.create("מבצע הפעלה מחדש", 
                "[COLOR yellow][B]אנא המתן...[/B][/COLOR]")
            DP.update(0)
            for s in range(5, -1, -1):
                time.sleep(1)
                if first_builds_restore=='':
                    DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n')
                    # DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה[/B][/COLOR]')
                else:
                    DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n')
                if DP.iscanceled():
                    from resources import win
                    return None, None
            from resources import win
        else:
            if first_builds_restore=='':
                DP.create("מבצע הפעלה מחדש", 
                "[COLOR yellow][B]אנא המתן...[/B][/COLOR]")
                # DP.create("מבצע הפעלה מחדש", 
                # "[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה[/B][/COLOR]")
            else:
                DP.create("מבצע הפעלה מחדש", 
                "[COLOR yellow][B]אנא המתן...[/B][/COLOR]")
            DP.update(0)
            for s in range(5, -1, -1):
                time.sleep(1)
                if first_builds_restore=='':
                    DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n')
                    # DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה[/B][/COLOR]')
                else:
                    DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n')
                if DP.iscanceled():
                    # os._exit(1)
                    from resources import android
                    return None, None
            from resources import android

def tele_account():
    import requests
    DIALOG         = xbmcgui.Dialog()
    try:  
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')

        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False

    if tele_source == True:
            import random
            num=random.randint(1,1001)
            data={'type':'td_send',
                         'info':json.dumps({'@type': 'getOption','name':'my_id', '@extra': num})
                         }
            event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            try:
                id=event2['value']
                if resuaddon.getSetting('normal_user')=='false':
                    if '1229060184'== id or '838481324'== id or '5667480303'== id or '5771387214'== id or '5984604232'== id or '5941680786'== id or '6022195851'== id or '6217448590'== id:
                        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Telemedia VIP'),'[COLOR %s]חשבון טלמדיה VIP כבר מוגדר.[/COLOR]' % COLOR2)
                        
                    else:
                        DIALOG         = xbmcgui.Dialog()
                        choice = DIALOG.yesno('Telemedia Vip', "כבר מוגדר לך חשבון טלמדיה, האם תרצה להגדיר אותו שוב?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
                        if choice == 0:
                            sys.exit()
                        else:
                           iiI1iIiI = translatepath ( os . path . join ( 'special://home/userdata/addon_data' , 'plugin.video.telemedia' ) )

                           shutil.rmtree(iiI1iIiI,ignore_errors=True, onerror=None)
                           resetkodi()
                else:
                
                    if resuaddon.getSetting('normal_user')=='true':
                        
                        choice = DIALOG.yesno('Telemedia', "האם לעבור מחשבון טלמדיה אישי לחשבון VIP?"+'\n'+ 'החשבון לא נמחק וניתן לחזור אליו על ידי לחיצה על חשבון טלמדיה אישי', yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
                        if choice :
                            # resuaddon.setSetting('vip_login2','true')
                            # resuaddon.setSetting('normal_user','false')
                            # xbmc.sleep(1500)
                            data={'type':'restart',
                                 'info':'vip'
                                 }
                            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                
            except:
                reset_telemedia()
    else:
            if resuaddon.getSetting('normal_user')=='true':
                
                choice = DIALOG.yesno('Telemedia', "האם לעבור מחשבון טלמדיה אישי לחשבון VIP?"+'\n'+ 'החשבון לא נמחק וניתן לחזור אליו על ידי לחיצה על חשבון טלמדיה אישי', yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
                if choice :
                    # resuaddon.setSetting('vip_login2','true')
                    # resuaddon.setSetting('normal_user','false')
                    data={'type':'restart',
                         'info':'vip'
                         }
                    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            else:
                    
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Telemedia VIP'),'[COLOR %s]המתן לתגובה מ Anonymous TV...[/COLOR]' % COLOR2)
                tele_account_down()


def clean_names(name):
    all_f=['ללא תרגום','ע"י י ב ג','@isrmovies','@kidsworldglobal','@LuluSratim1','*','+','תרגום מובנה','תרגום מובנ','שליו_סרטים','720p','bdrip','hevc','10bit','hdrisrael','ציקו מדיה','הועלה ע"י','pdtv','hedubbed','ddp','h 264','truee','hevcaac','hdrip','gramovies','קבוצת ים','שלום מדיה','פופקורן טיים','www moridim tv','amsi77','isrteleg','יהודה','עי רוני','4k','mp3','brrip','ripac3','6ch','sub','biuray','hevcaac','ד ס','brripac3','brripaac','2ch','smg','יוסי סרטים','עי יוסי','כל המדיה','hd tv','אלי ה ס','נתן ים','dvdrip','Segment 1','Segment 2','ISrTeLeG','עולם הסדרות','הועלה ע"י','שבי מדיה','צפייה ישירה','🎬','איכות',':','🇮🇱','לוי מדיה','#','Amsi77','קינג סרט','קרדיט','כל סרט','ᴴᴰ','סרטים וסדרות בדרייב','איילת השחר','anvip','bluray','web','dl','cam','CAM','h264','NoTime',' ק ס ','ק ס ',' ח ס ','ח ס ','גל שביט',' @cartoon join',' ז מ','ז.מ','xvid','EVO1','EVO2','RIp','נועםם','BDRiP','x265',' DivX',' WS','XViD','(',')','אלירן','WEB','H264',' Br','DVDRiP',' BRrip','DVDRIP','עי יוסי','נתי מ ','ע"י sagi','BDRIP','נתי ','עי אורי המלך','כל סרט ','כ.ס ','כ ס ','נמ ','H 264','HEVC','  ','לעברית','גזלן','מדיה סנטר','🔰','גבוהה מאד','~','=','#','סטאר מדיה','📺','💪','🥇','הומר ע"י צוותבן גביר','משה סדרות','@avikmedia','🔥','♨️','לוי סדרות','@brewfiles']

    name=name.replace('_','.').replace('dragonmedia','').replace('BluRay','').replace('BLURAY','').replace('הועלה_ע"י_יהודה_בן_גביר','').replace('ע"י_יהודה_בן_גביר','').replace('720_P','').replace('720P','').replace('720P','')
    
                              # .replace('_','.')
    name=name.replace(' ','.').replace('-','.').replace('%20',' ').replace('5.1','').replace('AAC','').replace('2CH','').replace('.mp4','').replace('.avi','').replace('.mkv','').replace('גוזלן','').replace('BDRip','').replace('BRRip','')

    name=name.replace('❤','').replace('⭕️','').replace('‼️','').replace('עולם הסדרות','').replace('טלגרמדיה','').replace('פופקורן טיים','').replace('לוי מדיה','').replace('BluRay','').replace('ח1','').replace('ח2','').replace('נתי.מדיה','').replace('נ.מ.','').replace('..','.').replace('.',' ').replace('WEB-DL','').replace('WEB DL','').replace('נ מדיה','')

    name=name.replace('HDTV','').replace('DVDRip','').replace('WEBRip','')

    name=name.replace('דב סרטים','').replace('לולו סרטים','').replace('דב ס','').replace('()','').replace('חן סרטים','').replace('ק סרטים','').replace('חננאל סרטים','').replace('יוסי סרטים','').replace('נריה סרטים','').replace('NF','').replace('HDCAM','').replace('@yosichen','')

    name=name.replace('BIuRay','').replace('x264','').replace('XviD','')

    name=name.replace('Silver007','').replace('Etamar','').replace('iSrael','').replace('DVDsot','').replace('אלי ה סרטים','').replace('PCD1','').replace('PCD2','').replace('CD1','').replace('CD2','').replace('CD3','').replace('Gramovies','').replace('BORip','').replace('200P','').replace('מס1','1').replace('מס2','2').replace('מס3','3').replace('מס4','4').replace('מס 3','3').replace('מס 2','2').replace('מס 1','1')

    name=name.replace('900p','').replace('PDTV','').replace('VHSRip','').replace('UPLOAD','').replace('TVRip','').replace('MP3','').replace('AC3','').replace('SMG','').replace('Rip','').replace('6CH','').replace('XVID','')

    name=name.replace('FHD','').replace('HD','').replace('WEBDL','').replace('DVDrip','')
    
    name=name.replace('מצוירים','').replace(' ק ס ','').replace(' ח ס ','').replace('ת מ ','').replace('חננאל ס','').replace('Empire סרטים','')
    name=name.replace('2נתי','2').replace('1נתי','1').replace('זירה מדיה','')
    name=name.replace('עי ליאת','').replace('עי אביאל','').replace('דניבר סרטים','').replace('ANVIP','').replace('מדיה VOD ','').replace('WEBRip_','').replace('@cartoon join','')
    name=name.replace('Madbadger','').replace('cd1','').replace('cd2','').replace('cd3','').replace('cd4','').replace('hdtv','').replace('bdrip','').replace('webrip','').replace('MkvCage','').replace('RickyChannel','').replace(',','')
   
    for items in all_f:
        name=name.replace(items,'')
    return name


def tele_account_not_vip():
    import requests
    DIALOG         = xbmcgui.Dialog()
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    
    try:  

        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False

    if tele_source == True:
        DIALOG.ok("Telemedia", 'כבר מוגדר לך חשבון טלמדיה')
    else:
        data={'type':'login',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
def tele_account_not_vip_old():

    import requests
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    
    try:  

        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False

    if tele_source == True:
            import random
            num=random.randint(1,1001)
            data={'type':'td_send',
                         'info':json.dumps({'@type': 'getOption','name':'my_id', '@extra': num})
                         }
            event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            try:
                id=event2['value']
            except:
                id=0
            DIALOG         = xbmcgui.Dialog()
            choice = DIALOG.yesno('Telemedia', "האם לעבור מחשבון טלמדיה VIP לחשבון אישי?"+'\n'+ 'החשבון לא נמחק וניתן לחזור אליו על ידי לחיצה על חשבון טלמדיה VIP', yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
            if choice == 0:
                sys.exit()
            else:
                # resuaddon.setSetting('autologin','true')
                # resuaddon.setSetting('vip_login2','false')
                # resuaddon.setSetting('normal_user','true')

                data={'type':'restart',
                     'info':'normal'
                     }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                
    else:
        # resuaddon.setSetting('autologin','true')
        # resuaddon.setSetting('vip_login2','false')
        # resuaddon.setSetting('normal_user','true')

        data={'type':'restart',
             'info':'normal'
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

def joinpack():
    telemedia=xbmcaddon.Addon('plugin.video.telemedia')
    vip_login2=telemedia.getSetting('vip_login2')
    if not vip_login2:
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.telemedia?mode=262&url=www)')
    else:
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Telemedia VIP'),'[COLOR %s]מוגדר לכם חשבון VIP - אתם מסודרים.[/COLOR]' % COLOR2)
def tele_account_firstbuild():
    if sys.platform.lower().startswith('darwin'):
        platform= (platform.architecture())
        if xbmc.getCondVisibility("system.platform.ios"):
            sys.exit()
        elif "AppleTV" in platform[1]:
            sys.exit()
    elif xbmc.getCondVisibility("system.platform.xbox"):
        sys.exit()
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    import requests
    try:  
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False

    if tele_source == True:
          xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
          LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]החשבון כבר מוגדר.[/COLOR]' % COLOR2)
    else:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        DIALOG         = xbmcgui.Dialog()
        choice = DIALOG.yesno('Telemedia VIP','להגדרת החשבון לחצו אישור', yeslabel="[B][COLOR white]אישור[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
        if choice == 1:
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)

            import threading
            from threading import Thread
            t = Thread(target=send_info, args=('sendtelemediapin','קוד טלמדיה',))
            t.start()
            resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
            user= resuaddon.getSetting("user")
            search_entered=get_pincode(code_link)
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            if search_entered==user:#new_num2:
            
               tele_account_down()
        else:
            retry_tele_account()
def tele_account_firstbuild_auto():

    if sys.platform.lower().startswith('darwin'):
        platform= (platform.architecture())
        if xbmc.getCondVisibility("system.platform.ios"):
            sys.exit()
        elif "AppleTV" in platform[1]:
            sys.exit()
    elif xbmc.getCondVisibility("system.platform.xbox"):
        sys.exit()
    import requests
    try:  
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False
    if tele_source == False:
            
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)
            tele_account_down()


def retry_tele_account():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno('הגדרת חשבון טלמדיה VIP', "לא היה מענה, האם לנסות שוב?", yeslabel="[B][COLOR WHITE]אישור[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
    if choice == 0:
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Telemedia VIP'),'[COLOR %s]בוטל[/COLOR]' % COLOR2)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
    else:
        import requests
        try:  
            resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
            listen_port=resuaddon.getSetting('port')
            data={'type':'checklogin',
                 'info':''
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            if event['status']==2 or event['status']=='Needs to log from setting':
                tele_source=False
                
            else:
                tele_source=True
        except:
            tele_source=False


        if tele_source == False:

                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)

                import threading
                from threading import Thread
                t = Thread(target=send_info, args=('sendtelemediapin','קוד טלמדיה',))
                t.start()
                search_entered=get_pincode(code_link)
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                if search_entered:
                   send_info('start_connect_tele','מתחיל באימות החשבון ')
                   # start_connect_tele()
                   tele_account_down()
                else:
                  retry_tele_account()

def p_mod():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno('הגדרת נעילה', "התהליך מתבצע פחות מדקה, להמשך לחצו אישור.", yeslabel="[B][COLOR WHITE]אישור[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
    if choice == 0:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
    else:
        import  threading
        from threading import Thread
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)
        import threading
        from threading import Thread
        t = Thread(target=send_info, args=('sendtelemediapin','סיסמת חבר',))
        t.start()
        search_entered=get_pincode(code_link)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        if search_entered:
            mediasync=xbmcaddon.Addon('plugin.video.telemedia')
            mediasync.setSetting('p_mod','true')
            xbmc.executebuiltin("Skin.SetBool(live_tv,true)")
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הרשאה נפתחה![/COLOR]' % COLOR2)
            send_info('open_t','הרשאה נפתחה')
            # open_t()
        else:
          LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הגדרת נעילה בוטלה[/COLOR]' % COLOR2)
          
          sys.exit()
def normalize(s):
    try:
        if type(s) == unicode: 
            return s.encode('utf8', 'ignore')
        else:
            return str(s)
    except:
        import unicodedata
        if type(s) == unicodedata: 
            return s.encode('utf8', 'ignore')
        else:
            return str(s)

TITLEB='באפר הוגדר בהצלחה'
def fix_buffer():

  src=__PLUGIN_PATH__ + "/resources/buffer/1/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer2():

  src=__PLUGIN_PATH__ + "/resources/buffer/2/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer3():

  src=__PLUGIN_PATH__ + "/resources/buffer/3/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer4():

  src=__PLUGIN_PATH__ + "/resources/buffer/4/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer5():

  src=__PLUGIN_PATH__ + "/resources/buffer/5/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer6():
  xbmc.executebuiltin("RunPlugin(plugin://plugin.program.Anonymous/?mode=autoadvanced)" )
def speed_test():
  from resources.lib.addon import run
  run()
  
def skin_pfix():
     addDir2("[COLOR white]תיקון חלון הגדרות - לבעלי קודי 17 בלבד!!![/COLOR]",'plugin.',300,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","תיקון חלון הגדרות - לבעלי קודי 17 בלבד!!!")
     addDir2("[COLOR white]שחזור הגדרות סקין[/COLOR]",'plugin.',24,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","שחזור הגדרות סקין")
     addDir2("[COLOR white]איפוס נעילת תצוגות[/COLOR]",'plugin.',231,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","איפוס נעילת תצוגות")
     addDir2("[COLOR white]איפוס הגדרות סקין[/COLOR]",'plugin.',200,__PLUGIN_PATH__ + "icon.png",__PLUGIN_PATH__ + "fanart.jpg","איפוס הגדרות סקין")

def resetForcedView():
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.episodes" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.episodes" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.episodes" type="string"></setting>'))
		file.close()
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.movies" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.movies" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.movies" type="string"></setting>'))
		file.close()
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.genres" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.genres" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.genres" type="string"></setting>'))
		file.close()
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.tvshows" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.tvshows" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.tvshows" type="string"></setting>'))
		file.close()
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.seasons" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.seasons" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.seasons" type="string"></setting>'))
		file.close()
		dialog = xbmcgui.Dialog()
		dialog.ok("Kodi Setting", 'התיקון עבר בהצלחה, הקודי יסדר כעת')
		os._exit(1)

def resetSKinSetting():
		os.remove(os.path.join(translatepath("special://userdata/"),"addon_data", "skin.Premium.mod", "settings.xml"))
		dialog = xbmcgui.Dialog()
		dialog.ok("Kodi Setting", 'התיקון עבר בהצלחה, הקודי יסדר כעת')
		os._exit(1)

def skin_efix():
        src=translatepath ( 'special://home/media')+"/settings.xml"
        dst=translatepath ( 'special://userdata/addon_data/skin.Premium.mod/')+"settings.xml"
        copyfile(src,dst)
        dialog = xbmcgui.Dialog()
        dialog.ok("Kodi Setting", 'התיקון עבר בהצלחה, הקודי יסגר כעת...')
        os._exit(1)
def skindialogsettind17():
        dialog = xbmcgui.Dialog()
        src=translatepath ( 'special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings17.xml"
        dst=translatepath ( 'special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"
        copyfile(src,dst)
        xbmc.executebuiltin("ReloadSkin()")
        dialog.ok("Kodi Setting", 'הושלם!')

def Set_OSD():
    dialog = xbmcgui.Dialog()
    funcs = (
        tv4,
        tv5,
        tv6,
        tv7,
        tv14,
        tv10,
        tv11,
        tv12,
        tv13,
        tv15,
        tv16,
        )
        
    call = dialog.select('תפריט מדיה', [
	'הצג/בטל כפתורים למסך טאץ',
	'גודל כתוביות - קטן',
	'גודל כתוביות - רגיל',
	'גודל כתוביות - גדול',
	'הפעל\בטל תרגום משפה זרה לעברית',
	'הורד כתוביות לשפה האנלית בלבד',
	'הורד כתוביות לשפה הספרדית בלבד',
	'הורד כתוביות לשפה הרוסית בלבד',
	'הורד כתוביות לשפה העברית בלבד',
	'שנה את שפת השמע לאנגלית',
	'שנה את שפת השמע לרוסית',])
    if call:
        if call < 0:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


oo='/wiz.key.xml'

def tv4():
    setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

    file = open(setting_file, 'r', encoding='utf-8') 
    file_data= file.read()
    file.close()
    regex='<setting id="playtouch" type="bool">(.+?)</setting>'
    m=re.compile(regex).findall(file_data)[0]
    if m=='true':
        xbmc.executebuiltin('Skin.SetBool(Playtouch,false)')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'ANONYMOUS TV'), "[COLOR %s]בוטל[/COLOR]" % COLOR2)
    else:
        xbmc.executebuiltin('Skin.SetBool(Playtouch,true)')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'ANONYMOUS TV'), "[COLOR %s]מופעל[/COLOR]" % COLOR2)
    xbmc.executebuiltin("ReloadSkin()")
def tv5():

	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontsize","value":40},"id":1}' )
	# xbmc.executebuiltin("ReloadSkin()")
def tv6():
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontsize","value":60},"id":1}' )
	# xbmc.executebuiltin("ReloadSkin()")
def tv7():
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontsize","value":70},"id":1}' )
	# xbmc.executebuiltin("ReloadSkin()")
def tv8():
   #בוטל - כתוביות אקריליות
   xbmc.executebuiltin( "Action(ShowSubtitles)" )
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.charset","value":"CP1251"}}')
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"arial.ttf"}}')
   xbmc.executebuiltin( "Action(ShowSubtitles)" )
def tv9():
   #בוטל - כתוביות אקריליות
   xbmc.executebuiltin( "Action(ShowSubtitles)" )
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.charset","value":"DEFAULT"}}')
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')
   xbmc.executebuiltin( "Action(ShowSubtitles)" )
def tv10():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"English"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '[COLOR=yellow]הורדת כתוביות לשפה האנגלית בוצעה בהצלחה[/COLOR]')))

def tv11():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Spanish"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '[COLOR=yellow]הורדת כתוביות לשפה הספרדית בוצעה בהצלחה[/COLOR]')))
def tv12():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Russian"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'הורדת כתוביות לשפה הרוסית בוצעה בהצלחה')))
def tv13():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','true')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Hebrew"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '[COLOR=yellow]הורדת כתוביות לשפה העברית בוצעה בהצלחה[/COLOR]')))
def tv14():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      subs=Addon.getSetting('auto_translate')
      if subs=='true':
         Addon.setSetting('auto_translate','false')
         LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'ANONYMOUS TV'), "[COLOR %s]תרגום משפה זרה בוטל.[/COLOR]" % COLOR2)
      if subs=='false':
         Addon.setSetting('auto_translate','true')
         LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'ANONYMOUS TV'), "[COLOR %s]תרגום משפה זרה הופעל.[/COLOR]" % COLOR2)
	# xbmc.executebuiltin('Action(togglefullscreen)')
def tv15():
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.audiolanguage","value":"English"}}')
   xbmc.executebuiltin( "Action(audionextlanguage)" )
def tv16():
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.audiolanguage","value":"Russian"}}')
   xbmc.executebuiltin( "Action(audionextlanguage)" )

def reset_telemedia():
    remove2=os.path.join(translatepath("special://home/userdata/addon_data/plugin.video.telemedia/database/"))
    telemedia=xbmcaddon.Addon('plugin.video.telemedia')
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם לאפס את חשבון הטלמדיה שלכם?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 0:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
    else:
       try:
           remove=os.path.join(translatepath("special://home/userdata/addon_data/plugin.video.telemedia/database_normal/"))
           if os.path.exists(remove):
                for root, dirs, files in os.walk(remove):
                    for f in files:
                        os.unlink(os.path.join(root, f))
       except:pass
            

       try:
           remove=os.path.join(translatepath("special://home/userdata/addon_data/plugin.video.telemedia/database/"))
           if os.path.exists(remove):
                for root, dirs, files in os.walk(remove):
                    for f in files:
                        os.unlink(os.path.join(root, f))
       except:pass

       telemedia.setSetting('autologin','true')
       telemedia.setSetting('vip_login2','false')

       try:
            os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.telemedia","4.1.1"))
       except:pass
       try:
            os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.telemedia","5.1.5"))
       except:pass
       try:
            send_info('sendp_mod_reset_tele_ok','החשבון אופס - ')
            # sendp_mod_reset_tele_ok()
       except:pass
       resetkodi()



def reset_telemedia_old():
    remove2=os.path.join(translatepath("special://home/userdata/addon_data/plugin.video.telemedia/database/"))
    telemedia=xbmcaddon.Addon('plugin.video.telemedia')
    vip_login2=telemedia.getSetting('vip_login2')
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם לאפס את חשבון הטלמדיה שלכם?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 0:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
    else:
        import random,requests
        
        listen_port=telemedia.getSetting('port')
        num=random.randint(1,1001)
        try :
            data={'type':'td_send',
                         'info':json.dumps({'@type': 'getOption','name':'my_id', '@extra': num})
                         }
            event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            try:
                id=event2['value']
            except:
                id=0

            if '1229060184'== id or '838481324'== id or '5667480303'== id or '5771387214'== id or '5984604232'== id or '5941680786'== id or '6022195851'== id or '6217448590'== id:
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]המתן לאיפוס על ידי Anonymous[/COLOR]' % COLOR2)
                import threading
                from threading import Thread
                t = Thread(target=send_info, args=('sendtelemediapin','בקשה לאיפוס חשבון טלמדיה',))
                t.start()
                search_entered=get_pincode(code_link)
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                if search_entered:
                   telemedia.setSetting('vip_login2','true')
                   telemedia.setSetting('autologin','false')
                   if os.path.exists(remove2):
                        for root, dirs, files in os.walk(remove2):
                            for f in files:
                                os.unlink(os.path.join(root, f))
                   try:
                        os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.telemedia","4.1.1"))
                   except:pass
                   try:
                        send_info('sendp_mod_reset_tele_ok','החשבון אופס - ')
                        # sendp_mod_reset_tele_ok()
                   except:pass
                   resetkodi()
                else:
                  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]האיפוס נכשל[/COLOR]' % COLOR2)
                  
                  sys.exit()
            else:
                   remove2=os.path.join(translatepath("special://home/userdata/addon_data/plugin.video.telemedia/database_normal/"))
                   telemedia.setSetting('autologin','false')
                   telemedia.setSetting('vip_login2','false')
                   if os.path.exists(remove2):
                        for root, dirs, files in os.walk(remove2):
                            for f in files:
                                os.unlink(os.path.join(root, f))
                   try:
                        os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.telemedia","4.1.1"))
                   except:pass
                   resetkodi()
        except:
            if telemedia.getSetting('normal_user')=='false':
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]המתן לאיפוס על ידי Anonymous[/COLOR]' % COLOR2)
                import threading
                from threading import Thread
                t = Thread(target=send_info, args=('sendtelemediapin','בקשה לאיפוס חשבון טלמדיה',))
                t.start()
                search_entered=get_pincode(code_link)
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                if search_entered:
                   # telemedia.setSetting('vip_login2','false')
                   telemedia.setSetting('autologin','true')
                   telemedia.setSetting('vip_login2','true')
                   if os.path.exists(remove2):
                        for root, dirs, files in os.walk(remove2):
                            for f in files:
                                os.unlink(os.path.join(root, f))
                   try:
                        os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.telemedia","4.1.1"))
                   except:pass
                   try:
                        send_info('sendp_mod_reset_tele_ok','החשבון אופס - ')
                        # sendp_mod_reset_tele_ok()
                   except:pass
                   resetkodi()
                else:
                  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]האיפוס נכשל[/COLOR]' % COLOR2)
                  
                  sys.exit()
            else:
               remove2=os.path.join(translatepath("special://home/userdata/addon_data/plugin.video.telemedia/database_normal/"))
               telemedia.setSetting('autologin','true')
               telemedia.setSetting('vip_login2','false')
               if os.path.exists(remove2):
                    for root, dirs, files in os.walk(remove2):
                        for f in files:
                            os.unlink(os.path.join(root, f))
               try:
                    os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.telemedia","4.1.1"))
               except:pass
               try:
                    send_info('sendp_mod_reset_tele_ok','החשבון אופס - ')
                    # sendp_mod_reset_tele_ok()
               except:pass
               resetkodi()


      
def purnpass():
    input= (Addon.getSetting("sex_pass"))
    dialog = xbmcgui.Dialog()
    search_entered=''
    keyboard = dialog.numeric(0, 'הכנס סיסמה')
    search_entered = keyboard
    if search_entered==input:
       xbmc.executebuiltin( "ActivateWindow(1113)" )
    else:
      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סיסמה שגויה[/COLOR]' % COLOR2)
      sys.exit()
def purnpass_change():

    dialog = xbmcgui.Dialog()
    search_entered=''
    keyboard = dialog.numeric(0, 'הכנס סיסמה חדשה')
    search_entered = keyboard
    Addon.setSetting('sex_pass',search_entered)
    if not search_entered=='':
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הסיסמה עודכנה![/COLOR]' % COLOR2)
def SUBS_English():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('language_english','true')
      Addon.setSetting('auto_translate','false')
      Addon.setSetting('language_russian','false')
      Addon.setSetting('language_arab','false')
      Addon.setSetting('language_hebrew','false')
      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שפת הכתובית שנבחרה - אנגלית[/COLOR]' % COLOR2)
      xbmc.executebuiltin( "RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)" )
def SUBS_Spanish():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')

      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שפת הכתובית שנבחרה - ספרדית[/COLOR]' % COLOR2)
      xbmc.executebuiltin( "RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)" )
def SUBS_Russian():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('language_russian','true')
      Addon.setSetting('auto_translate','false')
      Addon.setSetting('language_arab','false')
      Addon.setSetting('language_hebrew','false')
      Addon.setSetting('language_english','false')
      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שפת הכתובית שנבחרה - רוסית[/COLOR]' % COLOR2)
      xbmc.executebuiltin( "RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)" )
def SUBS_Arab():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('language_arab','true')
      Addon.setSetting('language_hebrew','false')
      Addon.setSetting('language_russian','false')
      Addon.setSetting('auto_translate','false')
      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שפת הכתובית שנבחרה - ערבית[/COLOR]' % COLOR2)
      xbmc.executebuiltin( "RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)" )

def SUBS_Hebrew():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('language_hebrew','true')
      Addon.setSetting('language_english','true')
      Addon.setSetting('auto_translate','true')
      Addon.setSetting('language_arab','false')
      Addon.setSetting('language_russian','false')
      xbmc.executebuiltin( "RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)" )
      
      # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Hebrew"}}')
      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שפת הכתובית שנבחרה - עברית[/COLOR]' % COLOR2)
def SUBS_Portugezit():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      
      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שפת הכתובית שנבחרה - פורטוגזית[/COLOR]' % COLOR2)

def fix_font():
  src=__PLUGIN_PATH__ + "/resources/Font.xml"
  dst=translatepath ( 'special://home/addons/skin.Premium.mod/16x9')+"/Font.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'תיקון עבר בהצלחה')
  xbmc.executebuiltin("ReloadSkin()")
def disfix_font():
  src=__PLUGIN_PATH__ + "/resources/disFont.xml"
  dst=translatepath ( 'special://home/addons/skin.Premium.mod/16x9')+"/Font.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'ביטול פונט עבר בהצלחה')
  xbmc.executebuiltin("ReloadSkin()")

def userkey():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    dialog = xbmcgui.Dialog()
    search_entered = dialog.numeric(0,'הכנס קוד פתיחה')
    found=0
    match=[]
    if search_entered=='':
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            return
    all_db=read_skin('key')
    for itt in all_db:
        items=all_db[itt]
        match.append((items['key']))
    for i in match:
        if i ==search_entered :
            found=1
    if found==1:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        

        from threading import Thread
        t = Thread(target=send_info, args=('userkey','נפתח '+search_entered,))
        t.start()
        if xbmc.getCondVisibility('system.platform.android') or xbmc.getCondVisibility('system.platform.windows'):
            import platform
            my_system = platform.uname()
            xs=my_system[1]
            resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')

            if not resuaddon.getSetting("platform_name")==xs and not resuaddon.getSetting("platform_name")=='':
                resuaddon.setSetting("platform_name",xs)
        

        # xbmc.sleep(500)

        xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
        xbmc.executebuiltin( "ActivateWindow(home)" )

    else:
       plugin = xbmcaddon.Addon('plugin.program.Anonymous')
       date= plugin.getSetting("date_user")
       check_user= plugin.getSetting("check_user")
       dragon= plugin.getSetting("dragon")
       if check_user=='false':
            if dragon=='true':
                contact_wiz('סיסמה שגויה, \nהמנוי שלכם הסתיים בתאריך: '+date+' \nלחידוש יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR ffe52b50]https://t.me/hedva44[/COLOR]\n ')
            else:
                contact_wiz('סיסמה שגויה, \nהמנוי שלכם הסתיים בתאריך: '+date+' \nלחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR ffe52b50]https://t.me/xbmc19[/COLOR]\n ')
       else:
            contact_wiz('סיסמה שגויה, \nלפתיחת הנעילה יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR ffe52b50]https://t.me/xbmc19[/COLOR]\n ')
       from threading import Thread
       t = Thread(target=send_info, args=('senderror','קוד פתיחה שגוי: '+search_entered,))
       t.start()
       xbmc.executebuiltin('Dialog.Close(busydialognocancel)')


def clear_search():
    try:
        remove2=os.path.join(translatepath("special://home/cache/archive_cache/"))
        if os.path.exists(remove2):
            for root, dirs, files in os.walk(remove2):
                for f in files:
                    os.unlink(os.path.join(root, f))
                # for d in dirs:
                    # shutil.rmtree(os.path.join(root, d))
            # os.rmdir(remove2)
    except:
        pass
    try:
        remove2=os.path.join(translatepath("special://home/temp/archive_cache/"))
        if os.path.exists(remove2):
            for root, dirs, files in os.walk(remove2):
                for f in files:
                    os.unlink(os.path.join(root, f))
                # for d in dirs:
                    # shutil.rmtree(os.path.join(root, d))
            # os.rmdir(remove2)
    except:
        pass
    try:
        remove2=os.path.join(translatepath("special://temp/archive_cache/"))
        if os.path.exists(remove2):
            for root, dirs, files in os.walk(remove2):
                for f in files:
                    os.unlink(os.path.join(root, f))
                # for d in dirs:
                    # shutil.rmtree(os.path.join(root, d))
            # os.rmdir(remove2)
    except:
        pass
def install_youtube():
    if not os.path.exists(xbmcvfs.translatePath("special://home/addons/") + "plugin://inputstream.adaptive/"):
       xbmc.executebuiltin("RunPlugin(plugin://inputstream.adaptive)" )
    if not os.path.exists(xbmcvfs.translatePath("special://home/addons/") + "plugin://plugin.video.youtube/") and os.path.exists(xbmcvfs.translatePath("special://home/addons/") + "plugin://inputstream.adaptive/"):

            xbmc.executebuiltin("RunPlugin(plugin://plugin.video.youtube)" )
    string='ActivateWindow(10025,"plugin://plugin.video.youtube/",return)'
    xbmc.executebuiltin(string)
def srt_background():
    m=Addon.getSetting('srt_background')
    
    if  m=='true':
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.backgroundtype","value":0}}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.bgopacity","value":0}}')
        Addon.setSetting('srt_background','false')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]כבוי[/COLOR]' % COLOR2)
    else:
        Addon.setSetting('srt_background','true')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.backgroundtype","value":2}}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.bgopacity","value":90}}')
        
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]פעיל[/COLOR]' % COLOR2)
def artwork(file):
    SKINFOLD       = os.path.join(__PLUGIN_PATH__,   'resources', 'skins', 'DefaultSkin', 'media')
    if file == 'slider': return os.path.join(SKINFOLD, 'Slider', 'osd_slider_nib.png'), os.path.join(SKINFOLD, 'Slider', 'osd_slider_nibNF.png'), os.path.join(SKINFOLD, 'Slider', 'slider1.png'), os.path.join(SKINFOLD, 'Slider', 'slider1.png')


def percentage(part, whole):
    return 100 * float(part)/float(whole)

def autoConfig(msg='', TxtColor='0xFFFFFFFF', Font='font12', BorderWidth=10):
    class MyWindow(xbmcgui.WindowDialog):
        scr={};
        def __init__(self,msg=msg,L=0,T=0,W=1280,H=720,TxtColor='0xFFFFFFFF',Font='font12',BorderWidth=10):

            self.TEXT = xbmcgui.ControlLabel(625, 380, width=150, height=50, label=msg+':', font='font35_title', textColor='0xFFFFFFFF')
            
            slidernibfocus, slidernibnofocus, sliderfocus, slidernofocus = artwork('slider')
            self.videoCacheSize=xbmcgui.ControlSlider(535, 415,200,20, textureback=sliderfocus, texture=slidernibnofocus, texturefocus=slidernibfocus, orientation=xbmcgui.HORIZONTAL)
            
            

            image_path = os.path.join(__PLUGIN_PATH__,   'resources', 'skins', 'DefaultSkin', 'media','Background','ContentPanel.png')

            
            self.BG=xbmcgui.ControlImage(517, 375,240,70, image_path, aspectRatio=0)
            self.addControl(self.BG)


            self.currentVideo1=xbmcgui.ControlTextBox(x=575, y=380, width=100, height=50,font='font35_title',textColor=TxtColor)
            self.addControl(self.currentVideo1)
   
            self.addControl(self.TEXT)
            self.addControl(self.videoCacheSize)
            if 'גודל כתובית' ==msg:

                self.currentRead=Addon.getSetting('subtitles.fontsize')
                self.currentVideo1.setText('[COLOR yellow]'+str(self.currentRead)+'[/COLOR]')
            if 'אטימות כתובית' ==msg:
                self.currentRead=Addon.getSetting('subtitles.opacity')
                self.currentVideo1.setText('[COLOR yellow]'+str(self.currentRead)+'[/COLOR]')


            self.readmax=100
            videopos = percentage(self.currentRead, self.readmax)
            self.videoCacheSize.setPercent(videopos)
        
        
            self.setFocus(self.videoCacheSize)
        def doExit(self):
            self.CloseWindow()


        def onAction(self, action):
            
            try: F=self.getFocus()
            except: F=False
            if action == ACTION_PREVIOUS_MENU:  self.doExit()
            elif action == ACTION_NAV_BACK:       self.doExit()
            elif action == ACTION_SELECT_ITEM:       self.doExit()
            
            self.currentVideo1.setText('[COLOR yellow]'+str(int(F.getPercent()))+'[/COLOR]')
            

            
            value = str(int(F.getPercent()))
            if 'גודל כתובית' ==msg:
                Addon.setSetting('subtitles.fontsize',value)
                new_key='subtitles.fontsize'
            if 'אטימות כתובית' ==msg:
                Addon.setSetting('subtitles.opacity',value)
                new_key='subtitles.opacity'
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"%s","value":%s}}'% (new_key,value))

        def CloseWindow(self): self.close()
    maxW=1280; maxH=720; W=int(900); H=int(650); L=int((maxW-W)/2); T=int((maxH-H)/2); 
    TempWindow=MyWindow(L=L,T=T,W=W,H=H,TxtColor=TxtColor,Font=Font,BorderWidth=BorderWidth); 
    TempWindow.doModal() 
    del TempWindow


def download_iptv_simple():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    from urllib.request import urlopen
    from urllib.request import Request

    import extract,platform
    machine= (platform.machine())
    platform= (platform.architecture())
    HOME           = translatepath('special://home/')
    ADDONS         = os.path.join(HOME,     'addons')
    PACKAGES       = os.path.join(ADDONS,   'packages')
    if sys.platform.lower().startswith('win'):
        link= 'https://digit.seedhost.eu/kodi/wizard/simple_iptv/win.zip'
    elif xbmc.getCondVisibility('system.platform.android'):
        if platform[0]=='32bit':
            link= 'https://digit.seedhost.eu/kodi/wizard/simple_iptv/android32.zip'
        else:
            link= 'https://digit.seedhost.eu/kodi/wizard/simple_iptv/android64.zip'
    iiI1iIiI = translatepath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    OOooO = os . path . join ( PACKAGES , 'isr.zip' )
    req = Request(link)
    remote_file = urlopen(req)
    f = open(OOooO, 'wb')
    try:
      total_size = remote_file.info().getheader('Content-Length').strip()
      header = True
    except AttributeError:
          header = False # a response doesn't always include the "Content-Length" header
    if header:
          total_size = int(total_size)
    bytes_so_far = 0
    start_time=time.time()
    while True:
          buffer = remote_file.read(8192)
          if not buffer:
              sys.stdout.write('\n')
              break

          bytes_so_far += len(buffer)
          f.write(buffer)

    II111iiii = translatepath ( os . path . join ( 'special://home/addons' ) )
    f.close()
    extract.all  ( OOooO , II111iiii)

    try:
      os.remove(OOooO)
    except:
      pass
    
    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.sleep(1000)
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format('inputstream.adaptive'))
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format('inputstream.ffmpegdirect'))
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format('inputstream.rtmp'))
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format('pvr.iptvsimple'))
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    resetkodi('true')
def set_iptv():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם תרצה להגדיר חשבון IPTV?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:

        # if not os.path.exists(os.path.join(ADDONS, 'pvr.iptvsimple')):
            # if xbmc.getCondVisibility('system.platform.windows') or xbmc.getCondVisibility('system.platform.android'):
                # download_iptv_simple()
            # else :
                # xbmc.executebuiltin("RunPlugin(plugin://pvr.iptvsimple)")

        # else:
            xbmc.executebuiltin('Addon.OpenSettings(%s)' % 'pvr.iptvsimple')
    else:
     sys.exit()
def movie_auto_play():
 
    cobra=xbmcaddon.Addon('plugin.video.cobra')
    auto_play_movie=cobra.getSetting('auto_play_movie')
    if auto_play_movie=='true':
        cobra.setSetting('auto_play_movie','false')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ניגון אוטומטי כבוי (סרטים)[/COLOR]' % COLOR2)
    else:
        cobra.setSetting('auto_play_movie','true')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ניגון אוטומטי מופעל (סרטים)[/COLOR]' % COLOR2)

def tv_auto_play():
 
    cobra=xbmcaddon.Addon('plugin.video.cobra')
    auto_play_episode=cobra.getSetting('auto_play_episode')
    if auto_play_episode=='true':
        cobra.setSetting('auto_play_episode','false')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ניגון אוטומטי כבוי (סדרות)[/COLOR]' % COLOR2)
    else:
        cobra.setSetting('auto_play_episode','true')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ניגון אוטומטי מופעל (סדרות)[/COLOR]' % COLOR2)
        
        

def toggle_stop():
    keymap_path = xbmcvfs.translatePath('special://profile/keymaps/ebs_custom_keyboard.xml')


    with xbmcvfs.File(keymap_path, 'r') as f:
        data = f.read()

    if "<backspace>Stop</backspace>" in data or "<back>Stop</back>" in data:
        # מבטל את Stop
        data = data.replace("<backspace>Stop</backspace>", "<backspace></backspace>")
        data = data.replace("<back>Stop</back>", "<back></back>")
        mode = '[COLOR yellow]כובה[/COLOR]'
    else:
        # מחזיר את Stop
        data = data.replace("<backspace></backspace>", "<backspace>Stop</backspace>")
        data = data.replace("<back></back>", "<back>Stop</back>")
        mode = '[COLOR yellow]הופעל[/COLOR]'

    with xbmcvfs.File(keymap_path, 'w') as f:
        f.write(data)

    LogNotify('AnonymousTV', f"{mode}")




params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
        url=unque(params["url"])
except:
        pass
try:
        name=unque(params["name"])
except:
        pass
try:
        iconimage=unque(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=unque(params["fanart"])
except:
        pass
try:        
        description=unque(params["description"])
except:
        pass

if mode==None or url==None or len(url)<1:
        main_menu()

elif mode==11:
        fix_buffer()

elif mode==15:
        fix_font()

elif mode==20:
        fix_buffer2()
elif mode==21:
        fix_buffer3()

elif mode==23:
        skin_pfix()
elif mode==231:

        resetForcedView()
elif mode==24:
        skin_efix()
elif mode==200:
        resetSKinSetting()
elif mode==25:
        fix_buffer4()

elif mode==32:
        disfix_font()
elif mode==33:
        fix_buffer5()

elif mode==39:
        fix_buffer6()
elif mode==40:
        speed_test()

elif mode==43:
       RD_All()
elif mode==44:
       SUBS_English()
elif mode==45:
       SUBS_Spanish()
elif mode==46:
       SUBS_Russian()
elif mode==416:
       SUBS_Portugezit()
elif mode==47:
       SUBS_Hebrew()

elif mode==70:
        reset_telemedia()
elif mode==290:
        purnpass()
elif mode==291:
    set_iptv()
elif mode==295:



    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.idanplus/?mode=4&module=iptv)")
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להפעיל את הקודי מחדש לאחר ההגדרה[/COLOR]' % COLOR2)
        # xbmc.executebuiltin( "ActivateWindow(home)" )
        # iptvidanplus()
        # xbmc.executebuiltin('Addon.OpenSettings(%s)' % 'pvr.iptvsimple')
    else:
     sys.exit()
elif mode==296:
        userkey()

elif mode==297:

    iptvkodi17()
elif mode==298:

    traktsync()
elif mode==299:

    trakt_off()

elif mode==300:

    skindialogsettind17()
elif mode=='purnpass'   : purnpass()
elif mode==301   : purnpass_change()
elif mode==51:     buffer()
elif mode==52:     kodi_usermenu()
elif mode==53:     USER_KODION()
elif mode==54:     rd_menu()
elif mode==182:    Set_OSD()
elif mode==183:    setrealdebrid()
elif mode==184:    rd_off()
elif mode==185:    logsend()#logsendme(enable_debug_notice=True)#logsend()
elif mode==186:    set_nextup()
elif mode==302:    tele_account()
elif mode==303:    Addon.openSettings()
elif mode==304:    menuoptions()
elif mode==305:
        p_mod()
elif mode==306:

    clear_search()
elif mode==307:
    install_youtube()

elif mode==309:

    srt_background()

elif mode==311:

    tele_account_firstbuild()


elif mode==320:
    rd_trakt_menu()
elif mode==321:
    user_setting_menu()
elif mode==322:
    fix_setting_menu()

elif mode==324:
    set_id_firebase()
elif mode==325:
     Addon.setSetting('firebase','')
     if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
        sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
        sync_tele.setSetting('firebase','')
        sync_tele.setSetting('sync_mod','false')
     if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
        sync_mando=xbmcaddon.Addon('plugin.video.mando')
        sync_mando.setSetting('firebase','')
        sync_mando.setSetting('sync_mod','false')
     xbmc.executebuiltin('Container.Refresh')
elif mode==326:

        telegram_save_menu()

elif mode==327:
    restore_backup_telegram()
elif mode==328:
    set_name_telegram_backup()
elif mode==329:
    telemedia=xbmcaddon.Addon('plugin.video.telemedia')
    if telemedia.getSetting("vip_login2")=='true':
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]כבר מוגדר ערוץ VIP לגיבוי[/COLOR]' % COLOR2)
    else:
        set_bot_id()
elif mode==330:

    backup_telegram(silent='False')
elif mode==331:
     Addon.setSetting('user_name','')
     Addon.setSetting('bot_id','')
     xbmc.executebuiltin('Container.Refresh')
elif mode==332:
    counter_ten=15
    while(counter_ten)>0:
        counter_ten-=1
        time.sleep(1)
    backup_telegram()


elif mode==338:
    xbmc.executebuiltin('Skin.SetBool(purn,false)')
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ON[/COLOR]' % COLOR2)
elif mode==339:
    xbmc.executebuiltin('Skin.SetBool(purn,true)')
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]OFF[/COLOR]' % COLOR2)
elif mode==340:
    xbmc.executebuiltin( "RunPlugin(plugin://plugin.program.Anonymous/?mode=open_turkey)" )
    
    
elif mode==341:
    set_folder_telemedia_files()
elif mode==342:
    
    tele_account_firstbuild_auto()
elif mode==343:
    delete_blocked_groups()
elif mode==344:
    tele_account_not_vip()
elif mode==345:

    joinpack()
elif mode==346:

    restore_backup_telegram('true')
elif mode==347:

    tele_account_down()
elif mode==348:
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "להחליף לתצוגת נוקס?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        swapSkins('skin.Premium.mod')




elif mode==349:
    user_dataDir_pre = translatepath('special://home/userdata/addon_data/skin.anonymoustv')
    if not os.path.exists(user_dataDir_pre):
        os.makedirs(user_dataDir_pre)
    src=translatepath ( 'special://home/addons/plugin.program.Settingz-Anon/resources/newskin')+"/settings.xml"
    dst=translatepath ( 'special://profile/addon_data/skin.anonymoustv')+"/settings.xml"
    copyfile(src,dst)
    xbmc.sleep(500)
    swapSkins('skin.anonymoustv')
    xbmc.sleep(1000)
    plugin = xbmcaddon.Addon('plugin.program.Anonymous')
    dragon= plugin.getSetting("dragon")
    src=translatepath ( 'special://home/addons/plugin.program.Settingz-Anon/resources/newskin')+"/settings.xml"
    dst=translatepath ( 'special://profile/addon_data/skin.anonymoustv')+"/settings.xml"
    copyfile(src,dst)
    if dragon=='true':
        xbmc.executebuiltin("Skin.SetBool(homemenunocustom4button,false)")
        xbmc.executebuiltin("ReloadSkin()")
    else: 
        xbmc.executebuiltin("Skin.SetBool(homemenunocustom4button,true)")
        xbmc.executebuiltin("ReloadSkin()")

elif mode==350:
    autoConfig(msg='גודל כתובית')
elif mode==351:
    autoConfig(msg='אטימות כתובית')
    
elif mode==352:
    xbmc.executebuiltin('ActivateWindowAndFocus(screencalibration, -100,1,-8,0)')
    # ActivateWindowAndFocus(skinsettings.xml,3000,1,3800,0)
    # xbmc.executebuiltin('ActivateWindowAndFocus(systemsettings, -100,0,-47,0)')
    
elif mode==353:
    SUBS_Arab()
elif mode==354:

    movie_auto_play()
elif mode==355:

    tv_auto_play()

elif mode==356:
    # # com.teamsmart.videomanager.tv, com.google.android.youtube, com.google.android.youtube.tv
    # video_id='34Na4j8AVgA'
    # # db_dir = translatepath('/storage/emulated/0/Android/data/com.teamsmart.videomanager.tv')
    # try:
    db_dir = translatepath('androidapp://sources/apps/yqtrack.app.png')
    os.listdir(db_dir)
    # app_id = 'com.teamsmart.videomanager.tv'
    # except:
        # try:
            # db_dir = translatepath('/storage/emulated/0/Android/data/com.google.android.youtube.tv')
            # os.listdir(db_dir)
            # app_id = 'com.google.android.youtube.tv'
        # except:
            # db_dir = translatepath('/storage/emulated/0/Android/data/com.google.android.youtube')
            # os.listdir(db_dir)
            # app_id = 'com.google.android.youtube'
    # app_id = 'com.google.android.youtube'
    # app_id2 = 'com.gold.android.youtube'
    # intent = 'android.intent.action.VIEW'

    # yturl = 'https://www.youtube.com/watch?v={}'.format(video_id)
    # start_activity2 = 'StartAndroidActivity({},{},,"{}")'.format(app_id2, intent, yturl)
    # start_activity = 'StartAndroidActivity({},{},,"{}")'.format(app_id, intent, yturl)
    # # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', start_activity)))
    # xbmc.executebuiltin(start_activity2)
    # xbmc.executebuiltin(start_activity)
    # db_dir = translatepath('androidapp://sources/apps/')
    # x=os.path.getsize(os.path.join(translatepath("androidapp://sources/apps/com.anydesk.anydeskandroid.png")))
    # db_path = os.path.join(db_dir)
    # for root in os.walk(db_path):
    # import glob
    # folder=os.path.getsize(os.path.join(translatepath("androidapp://sources/apps/")))
    # for file in glob.glob(folder):

        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', file)))



    # db_dir = translatepath('androidapp://sources/apps/com.anydesk.anydeskandroid.png')
    # db_path = os.path.join(db_dir)
    # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', db_path)))
    # for file in os.listdir(db_dir):
        # db_path = os.path.join(db_dir, file)
        # db_path=db_path.replace('/storage/emulated/0/Android/media/','')
        # logging.warning(db_path)
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', db_path)))
        # if 'com.google.android.youtube.tv'==db_path:
            # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'youtube.tv')))
            # sys.exit()
        # elif 'com.google.android.youtube'==db_path:
            # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'youtube')))
            # sys.exit()
        # elif 'com.teamsmart.videomanager.tv'==db_path:
            # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'teamsmart')))
            # sys.exit()
elif mode==357:
    rebootfromnand()
elif mode==358:

    toggle_stop()

if len(sys.argv)>0:

   xbmcplugin.endOfDirectory(int(sys.argv[1]))
