# coding: utf-8

import os, time, shutil, threading
import xbmc, xbmcaddon, xbmcgui, xbmcvfs

from resources.libs import wizard as wiz
from resources.libs.main import fix_gui, resetkodi

# קבועים ונתיבים
translatepath = xbmcvfs.translatePath
ADDON_ID = xbmcaddon.Addon().getAddonInfo("id")

ADDONTITLE   = wiz.addonInfo(ADDON_ID, 'name')
VERSION      = wiz.addonInfo(ADDON_ID, 'version')
ADDONPATH    = wiz.addonInfo(ADDON_ID, 'path')
DIALOG       = xbmcgui.Dialog()
DP           = xbmcgui.DialogProgress()
HOME         = translatepath('special://home/')
ADDONS       = os.path.join(HOME, 'addons')
USERDATA     = os.path.join(HOME, 'userdata')
ADDONDATA    = os.path.join(USERDATA, 'addon_data', ADDON_ID)
SETTINGS_FILE = os.path.join(ADDONDATA, 'settings.xml')
SETTINGS_BACKUP = os.path.join(ADDONDATA, 'settings.xml.bak')
SETTINGS_BACKUP_ALT = os.path.join(ADDONDATA, 'settings_backup.xml')
SKIN         = xbmc.getSkinDir()
BUILDNAME    = wiz.getS('buildname')
COLOR1       = wiz.getS('color1')
COLOR2       = wiz.getS('color2')
THUMBNAILS   = translatepath('special://home/userdata/Thumbnails')
setting      = xbmcaddon.Addon().getSetting
filesize_thumb = int(setting('filesizethumb_alert'))


# חזרה לבילד ברירת מחדל
def back_to_kodi():
    choice = DIALOG.yesno(
        ADDONTITLE, 
        "נראה שהייתה תקלה. האם לחזור לבילד?", 
        yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", 
        nolabel="[B][COLOR white]לא[/COLOR][/B]"
    )
    if choice:
        src = os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"), "20", "guisettings.xml")
        dst = os.path.join(USERDATA, "guisettings.xml")
        try:
            shutil.copyfile(src, dst)
            xbmc.sleep(200)
            fix_gui()
            resetkodi()
        except Exception as e:
            xbmc.log(f"[{ADDONTITLE}] Error restoring GUI settings: {e}", xbmc.LOGERROR)


# בדיקה אם יש צורך להפעיל שחזור
if SKIN in ['skin.confluence', 'skin.estuary', 'skin.estouchy'] and BUILDNAME:
    back_to_kodi()

# בדיקה אם להפעלת סטארטאפ
version_flag_file = os.path.join(ADDONDATA, '4.5.0')
if not os.path.exists(version_flag_file):
    os.makedirs(ADDONDATA, exist_ok=True)
    with open(version_flag_file, 'w') as f:
        f.write('Done')
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.Anonymous?mode=startup&url=www)')

# הפעלת עדכון אם skin לא מותקן
if not BUILDNAME and not os.path.exists(os.path.join(ADDONS, 'skin.anonymoustv')):
    wiz.wizardUpdateDP('startup')


# עדכון סקין במקרה שהוא חסר
try:
    skin_path = os.path.join(ADDONS, 'skin.estuary')
    if not os.path.exists(skin_path):
        from resources.libs import extract
        wiz.LogNotify(f"[COLOR {COLOR1}]{ADDONTITLE}[/COLOR]", f"[COLOR {COLOR2}]אנא המתן...[/COLOR]", 1500)
        setting_file = os.path.join(ADDONS, 'plugin.program.Anonymous', 'skin', 'packages1.zip')
        extract.all(setting_file, skin_path)
        xbmc.executebuiltin('UpdateLocalAddons()')
        xbmc.executebuiltin("ActivateWindow(home)")
        xbmc.executebuiltin("ReloadSkin()")
except Exception as e:
    xbmc.log(f"[{ADDONTITLE}] Error during skin extraction: {e}", xbmc.LOGERROR)


# מחיקת thumbnails אם חורגים מהמגבלה
def delete_thumbnails():
    total_size = 0
    for dirpath, _, filenames in os.walk(THUMBNAILS):
        for f in filenames:
            try:
                total_size += os.path.getsize(os.path.join(dirpath, f))
            except Exception:
                continue
    if (total_size / 1024000.0) > filesize_thumb:
        try:
            from resources.libs import maintenance
            maintenance.deleteThumbnails()
        except Exception as e:
            xbmc.log(f"[{ADDONTITLE}] Error deleting thumbnails: {e}", xbmc.LOGERROR)


# גיבוי קובץ הגדרות ושחזור במקרה של קובץ ריק
def backup_settings_file():
    try:
        if os.path.exists(SETTINGS_FILE):
            if os.path.getsize(SETTINGS_FILE) == 0:
                restored = False
                for candidate in (SETTINGS_BACKUP, SETTINGS_BACKUP_ALT):
                    if os.path.exists(candidate):
                        shutil.copyfile(candidate, SETTINGS_FILE)
                        xbmc.log(f"[{ADDONTITLE}] Restored settings.xml from backup {os.path.basename(candidate)}.", xbmc.LOGINFO)
                        restored = True
                        break
                if not restored:
                    try:
                        os.remove(SETTINGS_FILE)
                        xbmc.log(f"[{ADDONTITLE}] Removed empty settings.xml (no backup available).", xbmc.LOGWARNING)
                    except FileNotFoundError:
                        pass
            else:
                os.makedirs(ADDONDATA, exist_ok=True)
                temp_backup = SETTINGS_BACKUP + '.tmp'
                shutil.copyfile(SETTINGS_FILE, temp_backup)
                os.replace(temp_backup, SETTINGS_BACKUP)
        else:
            for candidate in (SETTINGS_BACKUP, SETTINGS_BACKUP_ALT):
                if os.path.exists(candidate):
                    shutil.copyfile(candidate, SETTINGS_FILE)
                    xbmc.log(f"[{ADDONTITLE}] Recreated missing settings.xml from backup {os.path.basename(candidate)}.", xbmc.LOGINFO)
                    break
    except Exception as e:
        xbmc.log(f"[{ADDONTITLE}] Error handling settings backup: {e}", xbmc.LOGERROR)


# הפעלה ראשונית של הגיבוי על סטארטאפ
backup_settings_file()

# הרצת פעולה כל X שניות
def every(delay, task):
    next_time = time.time() + delay
    while True:
        time.sleep(max(0, next_time - time.time()))
        try:
            task()
        except Exception as e:
            xbmc.log(f"[{ADDONTITLE}] Error in scheduled task: {e}", xbmc.LOGERROR)
        next_time += delay


# פונקציית עדכון
def check_update():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.Anonymous/?mode=update_tele)')


# הפעלת תהליך עדכון אם הבילד הוא "Kodi Premium"
if BUILDNAME == " Kodi Premium":
    wiz.LogNotify(f"[COLOR {COLOR1}]{ADDONTITLE}[/COLOR]", f"[COLOR {COLOR2}]System Is Started[/COLOR]", 500)

# אם סקין מתאים קיים – מריץ עדכון כל שעתיים
if any(os.path.exists(os.path.join(ADDONS, skin)) for skin in ['skin.Premium.mod', 'skin.anonymoustv']):

    threading.Thread(target=lambda: every(14400, check_update), daemon=True).start()
    check_update()
    delete_thumbnails()
